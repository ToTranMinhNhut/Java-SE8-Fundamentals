/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai10totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai1tinhTongHieuTichThuong {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap x: ");
        double x = Double.parseDouble(input.readLine());

        System.out.println("Nhap y: ");
        double y = Double.parseDouble(input.readLine());

        double ketqua = PhepTinh.CONG.Tinh(x, y);
        System.out.println("Ket qua; " + x + " + " + y + " = " + ketqua);

        ketqua = PhepTinh.TRU.Tinh(x, y);
        System.out.println("Ket qua; " + x + " - " + y + " = " + ketqua);

        ketqua = PhepTinh.TRU.Tinh(x, y);
        System.out.println("Ket qua; " + x + " * " + y + " = " + ketqua);

        ketqua = PhepTinh.CHIA.Tinh(x, y);
        System.out.println("Ket qua; " + x + " / " + y + " = " + ketqua);

    }
}

enum PhepTinh {

    CONG, TRU, NHAN, CHIA;

    double Tinh(double x, double y) {

        switch (this) {
            case CONG:
                return x + y;
            case TRU:
                return x - y;
            case NHAN:
                return x * y;
            case CHIA:
                return x / y;
            default:
                throw new AssertionError("Day khong phai phep tinh " + this);
        }
    }
}
