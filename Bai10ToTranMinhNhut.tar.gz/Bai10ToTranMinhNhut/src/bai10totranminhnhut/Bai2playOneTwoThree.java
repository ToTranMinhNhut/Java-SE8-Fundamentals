/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai10totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

/**
 *
 * @author hocvien
 */
public class Bai2playOneTwoThree {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nguoi choi nhap chon lua <<q, s, p, t>> <<quit, scissor, paper, stone >>: ");
        String optPlayer = input.readLine();

        int playtimes = 0, playermark = 0, computermark = 0;
        Option player = null, computer = null;

        Random random = new Random();

        if (optPlayer.equals("q")) {
            System.out.println("Thoat khoi tro choi");
        } else {
            while (playermark < 5 && computermark < 5) {

                if (optPlayer.equals("s")) {
                    player = Option.SCISSOR;
                } else if (optPlayer.equals("p")) {
                    player = Option.PAPER;
                } else if (optPlayer.equals("t")) {
                    player = Option.STONE;
                }

                int optComputer = random.nextInt(2);

                if (optComputer == 0) {
                    computer = Option.SCISSOR;
                } else if (optComputer == 1) {
                    computer = Option.PAPER;
                } else if (optComputer == 2) {
                    computer = Option.STONE;
                }

                if (computer.optionPlayer(player) == 0) {
                    playermark++;
                    System.out.println("Chuc mung ban da thang");

                } else if (computer.optionPlayer(player) == 1) {
                    System.out.println("Ngang tai ngang suc");
                } else if (computer.optionPlayer(player) == 2) {
                    computermark++;
                    System.out.println("Oh oh, ban thua roi");
                }

                if (playermark == 5) {
                    break;
                } else if (computermark == 5) {
                    break;
                }

                System.out.println("diem nguoi: " + playermark);
                System.out.println("diem may: " + computermark);

                playtimes++;

                System.out.println("Luot choi cua ban: " + playtimes);

                System.out.println("Nguoi choi nhap chon lua <<q, s, p, t>> <<quit, scissor, paper, stone >>: ");
                optPlayer = input.readLine();

                if (optPlayer.equals("q")) {
                    System.out.println("Thoat khoi tro choi");
                    break;
                }

            }

            if (playermark == 5) {
                System.out.println("Chuc mung ban da chien thang, diem cua ban la: " + playermark);
            } else if (computermark == 5) {
                System.out.println("Ban da thua, diem cua ban la: " + playermark);
            }
        }

    }

    enum Option {
        SCISSOR,
        PAPER,
        STONE;

        int optionPlayer(Option computer) {

            switch (this) {
                case SCISSOR:
                    if (computer.equals(SCISSOR)) {
                        return 1;
                    } else if (computer.equals(PAPER)) {
                        return 2;
                    } else if (computer.equals(STONE)) {
                        return 0;
                    }
                case PAPER:
                    if (computer.equals(SCISSOR)) {
                        return 0;
                    } else if (computer.equals(PAPER)) {
                        return 1;
                    } else if (computer.equals(STONE)) {
                        return 2;
                    }

                case STONE:
                    if (computer.equals(SCISSOR)) {
                        return 2;
                    } else if (computer.equals(PAPER)) {
                        return 0;
                    } else if (computer.equals(STONE)) {
                        return 1;
                    }
                default:
                    throw new AssertionError("chon chua khong phu hop");
            }
        }
    }
}
