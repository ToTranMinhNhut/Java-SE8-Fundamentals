/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai10totranminhnhut;

/**
 *
 * @author hocvien
 */
public class Bai3hienThiDenGiaoThong {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        System.out.println("Dèn " + DenGiaoThong.XANH.toString() + " chuyển sang đèn " + DenGiaoThong.XANH.chuyenDen().toString() + " với " + DenGiaoThong.XANH.giay() + " giây");
        System.out.println("Dèn " + DenGiaoThong.VANG.toString() + " chuyển sang đèn " + DenGiaoThong.VANG.chuyenDen().toString() + " với " + DenGiaoThong.VANG.giay() + " giây");
        System.out.println("Dèn " + DenGiaoThong.DO.toString() + " chuyển sang đèn " + DenGiaoThong.DO.chuyenDen().toString() + " với " + DenGiaoThong.DO.giay() + " giây");
    }

}

enum DenGiaoThong {
    XANH,
    VANG,
    DO;

    DenGiaoThong chuyenDen() {
        switch (this) {
            case XANH:
                return VANG;
            case DO:
                return XANH;
            case VANG:
                return DO;
            default:
                throw new AssertionError("Den khong phu hop");
        }
    }

    int giay() {
        switch (this) {
            case XANH:
                return 30;
            case DO:
                return 40;
            case VANG:
                return 10;
            default:
                throw new AssertionError("Den khong phu hop");
        }
    }

    @Override
    public String toString() {
        switch (this) {
            case XANH:
                return "Xanh";
            case DO:
                return "Đỏ";
            case VANG:
                return "Vàng";
            default:
                throw new AssertionError("Den khong phu hop");
        }
    }
}
