/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai10totranminhnhut;

/**
 *
 * @author hocvien
 */
public class Bai3hienThiDenGiaoThong {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}

enum DenGiaoThong {
    DO (30) {
        @Override
        public DenGiaoThong chuyenDen() {
            return XANH;
        }
    },
    
    VANG (10) {
        @Override
        public DenGiaoThong chuyenDen() {
            return DO;
        }
    },
    
    XANH(30) {
        @public DenGiaoThong chuyenDen() {
            return VANG;
        }
    };
    
    private DenGiaoThong(int soGiay) {
        
    }
    
}