/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai2TinhA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap n: ");
        int n = Integer.parseInt(input.readLine());

        System.out.println("Nhap x: ");
        float x = Float.parseFloat(input.readLine());

        double A = 0;

        if (n == 0) {
            A = 2;
        } else {
            double A1 = 1;
            double A2 = 1;

            for (int i = 1; i <= n; i++) {
                A1 *= (x * x + x + 1);
                A2 *= (x * x - x + 1);
                A = A1 + A2;
            }
        }

        System.out.println("A = " + A);
    }

}
