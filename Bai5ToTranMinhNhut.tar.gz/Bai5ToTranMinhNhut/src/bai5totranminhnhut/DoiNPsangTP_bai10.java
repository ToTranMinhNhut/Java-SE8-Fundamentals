/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class DoiNPsangTP_bai10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap so nhi phan: ");
        String nNhiPhan = input.readLine();
        double j = 0;

        int i = 0;
        while (i < nNhiPhan.length()) {
            if (nNhiPhan.charAt(i) == '1') {
                j = j + Math.pow(2, nNhiPhan.length() - 1 - i);
            }

            i++;
        }

        System.out.println("nhi phan: " + j);
    }

}
