/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai1TinhS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap n: ");
        int n = Integer.parseInt(input.readLine());

        System.out.println("Nhap x: ");
        int x = Integer.parseInt(input.readLine());

        double S = 1;

        if (n != 0) {
            for (int i = 1; i <= n; i++) {
                S *= (x * x + 1);
            }
        }

        System.out.println("S = (" + x + " * " + x + " + 1) mu " + n + " = " + S);

    }

}
