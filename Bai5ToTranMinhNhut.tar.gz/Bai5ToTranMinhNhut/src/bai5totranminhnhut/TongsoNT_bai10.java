/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class TongsoNT_bai10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap n: ");
        int n = Integer.parseInt(input.readLine());

        double E = 0;
        int i = 2;

        while (i <= n) {

            int count = 1;

            for (int j = 2; j <= i; j++) {
                if ((i % j) == 0) {
                    count++;
                }
            }

            if (count == 2) {
                E += i;
            }

            i++;
        }

        System.out.println("Ket qua E = " + E);
    }

}
