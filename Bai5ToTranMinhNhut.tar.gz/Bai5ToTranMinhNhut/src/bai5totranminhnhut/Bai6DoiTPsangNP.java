/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import static java.lang.Math.pow;

/**
 *
 * @author hocvien
 */
public class Bai6DoiTPsangNP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap n: ");
        int nThapPhan = Integer.parseInt(input.readLine());

        String re = "";
        while (nThapPhan > 0) {
            int mod = nThapPhan % 2;
            re = re + mod;
            nThapPhan /= 2;
        }
        re = new StringBuffer(re).reverse().toString();
        System.out.println(re);
    }
}
