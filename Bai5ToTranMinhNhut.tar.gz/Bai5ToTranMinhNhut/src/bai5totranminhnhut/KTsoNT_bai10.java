/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class KTsoNT_bai10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap x: ");
        int x = Integer.parseInt(input.readLine());

        int count = 1, i = 2;

        while (i <= x) {
            if ((x % i) == 0) {
                count++;
            }

            i++;
        }

        if (count == 2) {
            System.out.println(x + " la so Nguyen to!");
        } else {
            System.out.println(x + " khong phai la so nguyen to");
        }
    }

}
