/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai8tinhGiaiThua {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap n: ");
        int n = Integer.parseInt(input.readLine());

        double giaithua1 = tinhGiaiThua1(n);
        double giaithua2 = tinhGiaiThua2(n);

        System.out.println(n + "! = " + giaithua1);
        System.out.println(n + "!! = " + giaithua2);
    }

    public static double tinhGiaiThua1(int n) {
        double giaithua1 = 1;

        for (int i = 1; i <= n; i++) {
            giaithua1 *= i;
        }
        
        return giaithua1;
    }

    public static double tinhGiaiThua2(int n) {
        double giaithua2 = 1;

        if ((n % 2) == 0) {
            for (int i = 1; i <= n; i++) {
                if ((i % 2) == 0) {
                    giaithua2 *= i;
                }
            }
        } else {
            for (int i = 1; i <= n; i++) {
                if ((i % 2) != 0) {
                    giaithua2 *= i;
                }
            }
        }

        return giaithua2;
    }

}
