/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai6doiTPsangNP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap n: ");
        int nThapPhan = Integer.parseInt(input.readLine());

        String nNhiPhan = doiThanPhanSangNhiPhan(nThapPhan);
       
        System.out.println(nNhiPhan);
    }
    
    public static String doiThanPhanSangNhiPhan(int nThapPhan) {
        String ketqua = ""; 
        
        while (nThapPhan > 0) {
            int sodu = nThapPhan % 2;
            ketqua = ketqua + sodu;
            nThapPhan /= 2;
        }
        ketqua = new StringBuffer(ketqua).reverse().toString();
        
        return ketqua;
    }

}
