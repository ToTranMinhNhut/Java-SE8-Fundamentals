/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai8doiNPsangTP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        
         BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap so nhi phan: ");
        String nNhiPhan = input.readLine();
       
        double nThapPhan = doiSoNhiPhanSangSoThapPhan(nNhiPhan);

        
        System.out.println("nhi phan: " + nThapPhan) ;
    }
    
    public static double doiSoNhiPhanSangSoThapPhan(String n) {
        double nThapPhan = 0;
        
        for (int i = 0; i < n.length(); i++) {
            if (n.charAt(i) == '1') {
                nThapPhan += Math.pow(2, n.length() - 1 - i);
            }

        }
        
        return nThapPhan;
    }
    
}
