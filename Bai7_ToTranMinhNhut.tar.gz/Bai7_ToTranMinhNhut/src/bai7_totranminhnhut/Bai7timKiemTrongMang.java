/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai7timKiemTrongMang {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap n: ");
        int n = Integer.parseInt(input.readLine());

        System.out.println("Nhap cac gia tri cho cac phan tu trong mang: ");
        int[] arr = new int[n];
        nhapMang(n, arr);

        System.out.println("Nhap x: ");
        int x = Integer.parseInt(input.readLine());

        System.out.println("Mang da nhap: ");
        xuatMang(n, arr);
        System.out.println();

        timkiemPhanTuTrongMang(n, arr, x);

        System.out.println("Nhung so lon hon " + x);
        timPhanTuLonHonX(n, arr, x);
    }

    public static void nhapMang(int n, int[] arr) throws IOException {
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        for (int i = 0; i < n; i++) {
            arr[i] = Integer.parseInt(input.readLine());
        }
    }

    public static void xuatMang(int n, int[] arr) {
        for (int i = 0; i < n; i++) {
            System.out.print(arr[i] + " ");
        }
    }

    public static void timkiemPhanTuTrongMang(int n, int[] arr, int x) {
        for (int i = 0; i < n; i++) {
            if (x == arr[i]) {
                System.out.println(x + " xuat hien trong tai vi tri " + i);
            }

            if (x < arr[i]) {
                System.out.println(x + " khong lon hon cac so trong mang");
                break;
            }
        }
    }

    public static void timPhanTuLonHonX(int n, int[] arr, int x) {
        for (int i = 0; i < n; i++) {
            if (x < arr[i]) {
                System.out.println(arr[i]);
            }
        }
    }

}
