/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai1tinhS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap n: ");
        int n = Integer.parseInt(input.readLine());

        System.out.println("Nhap x: ");
        double x = Double.parseDouble(input.readLine());

        double S1 = 1;

        if (n != 0) {
            for (int i = 1; i <= n; i++) {
                S1 *= (x * x + 1);
            }
        }

        double S2 = tinhS(n, x);
        
        System.out.println("Canh viet thong thuong: S = (" + x + " * " + x + " + 1) mu " + n + " = " + S1);
        System.out.println("Canh viet ham: S = (" + x + " * " + x + " + 1) mu " + n + " = " + S2);

    }

    static double tinhS(int n, double x) {
        double S = 1;

        if (n != 0) {
            for (int i = 1; i <= n; i++) {
                S *= (x * x + 1);
            }
        }

        return S;
    }

}
