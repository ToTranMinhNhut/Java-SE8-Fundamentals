/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai9timCapSoMangMotChieu {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        int[] arr = new int[5];
        nhapMang(arr);

        System.out.println("Mang vua nhap: ");
        xuatMang(arr);
        System.out.println();

        System.out.println("Cac cap chia het: ");
        timCapSoQuanHeChiaHet(arr);

        System.out.println("Cac cap co quan he gap 2: ");
        timCapSoQuanHeGap2(arr);

        System.out.println("Cac cap co tong la 8: ");
        timCapSoTongBang8(arr);

    }

    public static void nhapMang(int[] arr) throws IOException {
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap mang: ");
        for (int i = 0; i < 5; i++) {
            arr[i] = Integer.parseInt(input.readLine());
        }
    }

    public static void xuatMang(int[] arr) {

        for (int i = 0; i < 5; i++) {
            System.out.print(arr[i] + " ");
        }
    }

    public static void timCapSoQuanHeChiaHet(int[] arr) {

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (((arr[i] % arr[j]) == 0) && (arr[i] != arr[j])) {
                    System.out.println(arr[i] + " & " + arr[j]);
                }
            }
        }
    }

    public static void timCapSoQuanHeGap2(int[] arr) {

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (((arr[i] * 2) == arr[j]) && (arr[i] != arr[j])) {
                    System.out.println(arr[i] + " & " + arr[j]);
                }
            }
        }
    }

    public static void timCapSoTongBang8(int[] arr) {

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (((arr[i] + arr[j]) == 8) && (arr[i] != arr[j])) {
                    System.out.println(arr[i] + " & " + arr[j]);
                }
            }
        }
    }

}
