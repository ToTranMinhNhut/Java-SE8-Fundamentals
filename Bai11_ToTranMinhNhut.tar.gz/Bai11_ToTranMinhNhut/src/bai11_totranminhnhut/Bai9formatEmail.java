/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author hocvien
 */
public class Bai9formatEmail {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap email: ");
        String email = input.readLine();

        Pattern p = Pattern.compile("[A-Za-z0-9-\\+_]+(\\.{1}[_A-Za-z0-9-]+)?@[A-Za-z0-9-]+\\.[A-Za-z0-9]+\\.?[A-Za-z]{2,}");
        Matcher m = p.matcher(email);

        if (m.matches()) {
            System.out.println("email hop le");
        } else {
            System.out.println("email khong hop le");
        }
    }

}
