/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author hocvien
 */
public class Bai7formatImageFileName {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.println("Nhap ten tap tin: ");
        String fileName = input.readLine();
        
        Pattern p = Pattern.compile("[^\t\n\r\f ][A-Za-z0-9.]+([j|J][p|P][g|G]|[g|G][i|I][f|F]|[p|P][n|N][g|G]|[b|B][m|M][p|P])");
        
        Matcher m = p.matcher(fileName);
        
        if (m.matches()) {
            System.out.println("ten file hop le");
        } else {
            System.out.println("Ten file khong hop le");
        }
    }
    
}
