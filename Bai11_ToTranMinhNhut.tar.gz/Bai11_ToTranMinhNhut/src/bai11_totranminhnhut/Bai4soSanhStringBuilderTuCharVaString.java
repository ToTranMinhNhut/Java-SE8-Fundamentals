/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_totranminhnhut;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai4soSanhStringBuilderTuCharVaString {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        
        StringBuilder sb1 = new StringBuilder();
        char A1;
        A1 = 'A';
        
        long thoigianSB1BD = System.currentTimeMillis();
        
        for (int i = 0; i < 10000; i++) {
            sb1 = sb1.append(A1);
        }
        long thoigianSB1KT = System.currentTimeMillis();
        long thoigianSB1 = thoigianSB1KT - thoigianSB1BD;
        
        String A2 = "A";
        StringBuilder sb2 = new StringBuilder();
        
        long thoigianSB2BD = System.currentTimeMillis();
        
        for (int i = 0; i < 10000; i++) {
            sb2 = sb2.append(A2);
        }
        
        long thoigianSB2KT = System.currentTimeMillis();
        
        long thoigianSB2 = thoigianSB2KT - thoigianSB2BD;
        
        System.out.println("Chieu dai chuoi st: " + sb1.length());
        System.out.println("Chieu dai chuoi sb: " + sb2.length());
        System.out.println("Thoi gian thuc hien sb1: " + thoigianSB1);
        System.out.println("Thoi gian thuc hien sb2: " + thoigianSB2);
    }
    
}
