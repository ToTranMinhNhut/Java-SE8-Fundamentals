/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai2xulyChuoiStringBuilder {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap sb: ");
        StringBuilder sb = new StringBuilder();
        sb.append(input.readLine());

        inTungKituTrongChuoi(sb);

        System.out.println("Nhap kt: ");
        StringBuilder kt = new StringBuilder();
        kt.append(input.readLine());

        timChuoi(sb, kt);

    }

    public static void inTungKituTrongChuoi(StringBuilder sb) {

        char kiTu;
        for (int i = 0; i < sb.length(); i++) {
            kiTu = sb.charAt(i);
            System.out.println(kiTu);
        }
    }

    public static void timChuoi(StringBuilder sb, StringBuilder kt) {

        int vitri = sb.toString().indexOf(kt.toString());

        if (vitri >= 0) {
            System.out.println("Vi tri duoc tim thay: " + vitri);
        } else {
            System.out.println("Khong tim thay");
        }

    }

}
