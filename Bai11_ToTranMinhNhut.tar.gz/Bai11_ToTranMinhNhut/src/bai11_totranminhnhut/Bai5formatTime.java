/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author hocvien
 */
public class Bai5formatTime {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap gio vao: ");
        String time = input.readLine();

        Pattern p = Pattern.compile("([0-1]?[0-9]|2[0-3]):[0-5]?[0-9]");

        Matcher m = p.matcher(time);

        boolean r = m.matches();

        if (r) {
            System.out.println("Gio hop le");
        } else {
            System.out.println("Gio khong hop le");
        }
    }

}
