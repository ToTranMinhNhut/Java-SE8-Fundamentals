/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai2xuLyChuoiStringBuilder {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.println("Nhap chuoi sb: ");
        StringBuilder sb = new StringBuilder();
        sb.append(input.readLine());
        
        System.out.println("Nhap chuoi sb1: ");
        StringBuilder sb1 = new StringBuilder();
        sb1.append(input.readLine());

        System.out.println("Nhap chuoi sb2: ");
        StringBuilder sb2 = new StringBuilder();
        sb2.append(input.readLine());

        System.out.println("Nhap chuoi sb3: ");
        StringBuilder sb3 = new StringBuilder();
        sb3.append(input.readLine());

        System.out.println("Nhap chuoi sb4: ");;
        StringBuilder sb4 = new StringBuilder();
        sb4.append(input.readLine());

        System.out.println("Nhap vi tri chen: ");
        int posInsert = Integer.parseInt(input.readLine());

        System.out.println("Nhap vi tri dau: ");
        int posFirst = Integer.parseInt(input.readLine());

        System.out.println("Nhap vi tri cuoi: ");
        int posLast = Integer.parseInt(input.readLine());

        System.out.println("Chieu dai sb1: " + sb1.length());
        System.out.println("Chieu dai sb2: " + sb2.length());
        System.out.println("Chieu dai sb3: " + sb3.length());
        System.out.println("Chieu dai sb4: " + sb4.length());
        
        sb.append(sb1);
        System.out.println("Chuoi sb sau khi noi sb1: " + sb);
        
        sb.insert(posInsert, sb2);
        System.out.println("Chuoi sb sau khi chen sb2 tai vi tri : " + posInsert + " la: " + sb);
        
        sb.delete(posFirst, posLast);
        System.out.println("Chuoi sb sau khi xoa tu vi tri " + posFirst + " den " + posLast + " la: " + sb);
        
        sb.reverse();
        System.out.println("Chuoi sb sau khi dao nguoc: " + sb);
    }

}
