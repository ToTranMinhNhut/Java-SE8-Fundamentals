/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import jdk.nashorn.internal.objects.NativeString;

/**
 *
 * @author hocvien
 */
public class Bai1xuLyChuoi {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap chuoi s1: ");
        String s1 = input.readLine();

        System.out.println("Nhap chuoi s2: ");
        String s2 = input.readLine();

        System.out.println("Nhap chuoi s3: ");
        String s3 = input.readLine();

        System.out.println("Nhap vi tri v: ");
        int posV = Integer.parseInt(input.readLine());

        System.out.println("Chieu dai cua chuoi s1: " + s1.length());
        System.out.println("Chieu dai cua chuoi s1: " + s2.length());
        System.out.println("Chieu dai cua chuoi s1: " + s3.length());

        int compare = s1.compareTo(s2);
        System.out.println("Ket qua so s1 & s2: " + compare);

        int position = s1.indexOf(s3);
        System.out.println("Vi tri xuat hien dau tien cua chuoi s3 trong s1: " + position);

        String s4 = s1.substring(posV);
        System.out.println("Chuoi s4: " + s4);
    }
}
