/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_totranminhnhut;

/**
 *
 * @author hocvien
 */
public class Bai5hienthiMaTranChuoi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here'
        
        System.out.println("a");
        hinhA();
        
        System.out.println("b");
        hinhB();
        
        System.out.println("c");
        hinhC();
        
        System.out.println("d");
        hinhD();
        
        System.out.println("e");
        hinhE();
        
        System.out.println("f");
        hinhF();
        
        System.out.println("g");
        hinhG();
        
        System.out.println("h");
        hinhH();
        
        System.out.println("i");
        hinhI();

    }

    public static void hinhA() {

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (i >= j) {
                    System.out.print("#");
                }
            }

            System.out.println();
        }
    }

    public static void hinhB() {

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (i <= j) {
                    System.out.print("#");
                }
            }

            System.out.println();
        }
    }

    public static void hinhC() {

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (i <= j) {
                    System.out.print("#");
                } else {
                    System.out.print(" ");
                }
            }

            System.out.println();
        }
    }

    public static void hinhD() {

        for (int i = 8; i >= 0; i--) {
            for (int j = 0; j < 8; j++) {
                if (i <= j) {
                    System.out.print("#");
                } else {
                    System.out.print(" ");
                }
            }

            System.out.println();
        }
    }

    public static void hinhE() {

        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                if (i == 6 || j == 6 || i == 0 || j == 0) {
                    System.out.print("#");
                } else {
                    System.out.print(" ");
                }
            }

            System.out.println();
        }
    }

    public static void hinhF() {

        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                if (i == 6 || i == 0 || j == i) {
                    System.out.print("#");
                } else {
                    System.out.print(" ");
                }
            }

            System.out.println();
        }
    }

    public static void hinhG() {

        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                if (i == 6 || i == 0 || j + i == 6) {
                    System.out.print("#");
                } else {
                    System.out.print(" ");
                }
            }

            System.out.println();
        }
    }

    public static void hinhH() {

        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                if (i == 6 || i == 0 || j + i == 6 || i == j) {
                    System.out.print("#");
                } else {
                    System.out.print(" ");
                }
            }

            System.out.println();
        }
    }

    public static void hinhI() {

        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                if (i == 6 || j == 6 || i == 0 || j == 0 || (j + i) == 6 || i == j) {
                    System.out.print("#");
                } else {
                    System.out.print(" ");
                }
            }

            System.out.println();
        }
    }

}
