/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

/**
 *
 * @author hocvien
 */
public class Bai3phanTachNgayThangNam {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap ngay thang nam: ");
        String ngayThangNam = input.readLine();

        StringTokenizer ntn;
        ntn = new StringTokenizer(ngayThangNam,"-");

        String ngay = ntn.nextToken();
        System.out.println("Ngay: " + ngay);

        String thang = ntn.nextToken();
        System.out.println("Thang: " + thang);

        String nam = ntn.nextToken();
        System.out.println("Nam: " + nam);

    }

}
