/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_totranminhnhut;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai3soSanhStringVaStringBuilder {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        String st = "";
        long thoigianStringBD = System.currentTimeMillis();

        for (int i = 0; i < 10000; i++) {
            st = st.concat(i + " ");
        }
        long thoigianStringKT = System.currentTimeMillis();

        StringBuilder sb = new StringBuilder();
        long thoigianStringBuilderBD = System.currentTimeMillis();
        long thoigianString = thoigianStringKT - thoigianStringBD;

        for (int i = 0; i < 10000; i++) {
            sb = sb.append(i + " ");
        }
        long thoigianStringBuilderKT = System.currentTimeMillis();
        long thoigianStringBuilder = thoigianStringBuilderKT - thoigianStringBuilderBD;

        System.out.println("Chieu dai chuoi st: " + st.length());
        System.out.println("Chieu dai chuoi sb: " + sb.length());
        System.out.println("Thoi gian thuc hien st: " + thoigianString);
        System.out.println("Thoi gian thuc hien sb: " + thoigianStringBuilder);

    }

}
