/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author hocvien
 */
public class Bai6formatUsername {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap username: ");
        String username = input.readLine();
        
        Pattern p = Pattern.compile("[a-z0-9_-]{6,20}");
        
        Matcher m = p.matcher(username);
        
        if (m.matches()) {
            System.out.println("username hop le");
        } else {
            System.out.println("username khong he le");
        }
    }

}
