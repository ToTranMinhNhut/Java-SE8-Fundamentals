/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

/**
 *
 * @author hocvien
 */
public class Bai1xulyMangChuoi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap n: ");
        int n = Integer.parseInt(input.readLine());

        String[] mangTen = new String[n];
        nhapMangChuoi(mangTen, n);

        System.out.println("Mang chuoi vua nhap: ");
        xuatMangChuoi(mangTen, n);

        System.out.println("Nhap ten: ");
        String ten = input.readLine();

        timChuoi(mangTen, n, ten);

        timPhanTuChuaN(mangTen, n);

        Arrays.sort(mangTen);
        xuatMangChuoi(mangTen, n);

    }

    public static void nhapMangChuoi(String[] st, int n) throws IOException {
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        for (int i = 0; i < n; i++) {
            System.out.println("Phan tu thu [" + i + "]: ");
            st[i] = input.readLine();
        }
    }

    public static void xuatMangChuoi(String[] st, int n) {

        for (int i = 0; i < n; i++) {
            System.out.println("Phan tu thu: " + i + " la: " + st[i]);
        }
    }

    public static void timChuoi(String[] st, int n, String ten) {
        int tam = 0, vitri = 0;

        for (int i = 0; i < n; i++) {
            if (st[i].equals(ten)) {
                tam++;
                vitri = i;
                break;
            }
        }

        if (tam != 0) {
            System.out.println("Vi tri cua dau tien xuat hien cua ten : " + vitri);
        } else {
            System.out.println("ten khong ton tai trong mang");
        }

    }

    public static void timPhanTuChuaN(String[] st, int n) {

        for (int i = 0; i < n; i++) {
            if (st[i].indexOf("n") >= 0) {
                System.out.println("Phan tu co chua ki tu n: " + st[i]);
            }
        }
    }

}
