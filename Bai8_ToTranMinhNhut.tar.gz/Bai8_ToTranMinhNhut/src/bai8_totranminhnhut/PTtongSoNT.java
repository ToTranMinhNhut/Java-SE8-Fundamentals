/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author minhnhutvaio
 */
public class PTtongSoNT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        int n = 0;

        try {
            System.out.println("Nhap n: ");
            n = Integer.parseInt(input.readLine());

        } catch (NumberFormatException e) {
            System.out.println("Loi: " + e);
        }

        double E = tongSoNguyenTo(n);

        System.out.println("Ket qua E = " + E);
    }

    public static boolean kiemtraSoNguyenTo(int x) {
        int count = 1;

        for (int i = 2; i <= x; i++) {
            if ((x % i) == 0) {
                count++;
            }
        }

        return count == 2;
    }

    public static double tongSoNguyenTo(int n) {
        double E = 0;

        if (n < 0) {
            throw new ArithmeticException("Loi n khong duoc am");
        }

        for (int i = 2; i <= n; i++) {

            if (kiemtraSoNguyenTo(i)) {
                E += i;
            }
        }

        return E;
    }

}
