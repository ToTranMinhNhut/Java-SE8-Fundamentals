/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author minhnhutvaio
 */
public class PTdoiNPsangTP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        String nNhiPhan = "";

        try {
            System.out.println("Nhap so nhi phan: ");
            nNhiPhan = input.readLine();

        } catch (NullPointerException e) {
            System.out.println("Loi: " + e.getMessage());
        }
        
        double nThapPhan = doiSoNhiPhanSangSoThapPhan(nNhiPhan);

        System.out.println("nhi phan: " + nThapPhan);
    }

    public static double doiSoNhiPhanSangSoThapPhan(String n) {
        double nThapPhan = 0;
        
        for (int i = 0; i < n.length(); i++) {
            if (n.charAt(i) == '1') {
                nThapPhan += Math.pow(2, n.length() - 1 - i);
            }
        }

        return nThapPhan;
    }

}
