/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

/**
 *
 * @author minhnhutvaio
 */
public class MangxulyMangNgauNhien {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        int n = 0;

        try {
            System.out.println("Nhap n: ");
            n = Integer.parseInt(input.readLine());
            
        } catch (NumberFormatException e) {
            System.out.println("Loi: " + e.getMessage());
        }
        
        if (n < 0) {
            throw new NegativeArraySizeException("Loi Mang khong co phan tu");
        }
        
        int[] arr = new int[n];
        Random random = new Random();

        for (int i = 0; i < n; i++) {
            arr[i] = random.nextInt(n);
        }

        int SummArr = 0;
        for (int value : arr) {
            System.out.print(value + " ");
            SummArr += value;
        }

        System.out.println("\nTong : " + SummArr);
    }

}
