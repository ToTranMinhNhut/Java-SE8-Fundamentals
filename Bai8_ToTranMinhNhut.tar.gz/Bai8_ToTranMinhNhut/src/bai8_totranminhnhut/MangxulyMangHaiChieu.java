/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author minhnhutvaio
 */
public class MangxulyMangHaiChieu {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        int n = 0, m = 0;

        // Nhap mang hai chieu
        try {
            System.out.println("Nhap so dong n: ");
            n = Integer.parseInt(input.readLine());

            System.out.println("Nhap so cot m: ");
            m = Integer.parseInt(input.readLine());

        } catch (NumberFormatException e) {
            System.out.println("Loi: " + e);
        }

        if (n < 0 || m < 0) {
            throw new NegativeArraySizeException("Loi Mang khong co phan tu");
        }

        int[][] arr = new int[n][m];

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print("Nhap phan thu " + "[" + i + "]" + "[" + j + "]" + ": ");
                arr[i][j] = Integer.parseInt(input.readLine());
            }
        }

        // Xuat mang hai chieu
        System.out.println("Mang hai chieu vua nhap: ");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print(arr[i][j] + " ");
            }
            System.out.println();
        }

        int chan = 0, le = 0, LonNhat = arr[0][0], NhoNhat = arr[0][0], am = 0;
        float TongChan = 0, TongLe = 0;

        // xu ly mang 2 chieu
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {

                if ((arr[i][j] % 2) == 0) {
                    chan++;
                    TongChan += arr[i][j];
                } else {
                    le++;
                    TongLe += arr[i][j];
                }

                if (LonNhat <= arr[i][j]) {
                    LonNhat = arr[i][j];
                }

                if (arr[i][j] <= NhoNhat) {
                    NhoNhat = arr[i][j];
                }

                if (arr[i][j] < 0) {
                    am++;
                }
            }
        }

        System.out.println("So phan tu chan: " + chan);
        System.out.println("So phan tu le:" + le);

        if (chan > 0) {
            float TrungBinhChan = TongChan / chan;
            System.out.println("Trung binh cac phan tu chan: " + TrungBinhChan);
        } else {
            throw new ArithmeticException("Loi chia cho 0");
        }

        if (le > 0) {
            float TrungBinhLe = TongLe / le;
            System.out.println("Trung binh cac phan tu le: " + TrungBinhLe);
        } else {
            throw new ArithmeticException("Loi chia cho 0");
        }

        System.out.println("Phan tu lon nhat trong mang la: " + LonNhat);
        System.out.println("Phan tu nho nhat trong mang la: " + NhoNhat);

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {

                if (LonNhat == arr[i][j]) {
                    System.out.println("phan tu lon nhat trong mang co vi tri la: dong " + i + " cot " + j);
                }

                if (NhoNhat == arr[i][j]) {
                    System.out.println("phan tu nho nhat trong mang co vi tri la: dong " + i + " cot " + j);
                }
            }
        }

        // tim phan tu am trong mang
        if (am != 0) {
            System.out.println("Ma tran co phan tu ");
        } else {
            System.out.println("Ma tran khong co phan tu am");
        }
    }

}
