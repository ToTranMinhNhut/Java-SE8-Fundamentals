/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author minhnhutvaio
 */
public class PTtinhNamAmLich {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException, Exception {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        int nam = 0;
        System.out.println("Nhap nam: ");

        try {
            nam = Integer.parseInt(input.readLine());

        } catch (NumberFormatException e) {
            System.out.println("Loi: " + e.getMessage());
        }

        String Can = tinhCan(nam);
        String Chi = tinhChi(nam);

        System.out.println("Nam " + nam + " trong am lich la nam: " + Can + " " + Chi);
    }

    public static String tinhCan(int year) {
        String can = "";
        
        if (year < 0) {
            throw new ArithmeticException("Loi Nam khong duoc am ");
        }

        int tam = year % 10;

        switch (tam) {
            case 0:
                can = "Canh";
                break;
            case 1:
                can = "Tân";
                break;
            case 2:
                can = "Nhâm";
                break;
            case 3:
                can = "Qúy";
                break;
            case 4:
                can = "Giáp";
                break;
            case 5:
                can = "Ất";
                break;
            case 6:
                can = "Bính";
                break;
            case 7:
                can = "Đinh";
                break;
            case 8:
                can = "Mậu";
                break;
            case 9:
                can = "Kỳ";
                break;
        }

        return can;
    }

    public static String tinhChi(int year) {
        String chi = "";
        int tam = year % 12;

        switch (tam) {
            case 0:
                chi = "Thân";
                break;
            case 1:
                chi = "Dậu";
                break;
            case 2:
                chi = "Tuất";
                break;
            case 3:
                chi = "Hợi";
                break;
            case 4:
                chi = "Tý";
                break;
            case 5:
                chi = "Sửu";
                break;
            case 6:
                chi = "Dần";
                break;
            case 7:
                chi = "Mão";
                break;
            case 8:
                chi = "Thìn";
                break;
            case 9:
                chi = "Tỵ";
                break;
            case 10:
                chi = "Ngọ";
                break;
            case 11:
                chi = "Mùi";
        }

        return chi;
    }

    private static Exception ArithmeticException(String loi_Nam_khong_the_am) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
