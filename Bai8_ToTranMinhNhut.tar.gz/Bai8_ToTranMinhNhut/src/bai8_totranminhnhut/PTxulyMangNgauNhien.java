/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

/**
 *
 * @author minhnhutvaio
 */
public class PTxulyMangNgauNhien {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        int n = 0;

        try {
            System.out.println("Nhap n: ");
            n = Integer.parseInt(input.readLine());

        } catch (NumberFormatException e) {
            System.out.println("Loi: " + e.getMessage());
        }
        
        int[] arr = new int[n];
        phatsinhMangNgauNhien(n, arr);

        int SumArr = tongMangNgauNhien(n, arr);

        System.out.println("\nTong : " + SumArr);
    }

    public static void phatsinhMangNgauNhien(int n, int[] arr) {
        
        if (n <= 0) {
            throw new NegativeArraySizeException("Mang khong co phan tu");
        }
        
        Random random = new Random();

        for (int i = 0; i < n; i++) {
            arr[i] = random.nextInt(n);
        }
    }

    public static int tongMangNgauNhien(int n, int[] arr) {
        int SumArr = 0;

        for (int value : arr) {
            System.out.print(value + " ");
            SumArr += value;
        }

        return SumArr;
    }

}
