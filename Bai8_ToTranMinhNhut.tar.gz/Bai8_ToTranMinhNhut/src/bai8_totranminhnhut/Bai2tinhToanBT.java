/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import static java.lang.Math.sqrt;

/**
 *
 * @author minhnhutvaio
 */
public class Bai2tinhToanBT {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        double A = 0;
        
        try {

            System.out.println("Nhap x: ");
            int x = Integer.parseInt(input.readLine());

            System.out.println("Nhap y: ");
            int y = Integer.parseInt(input.readLine());

            A = tinhBT(x, y);

        } catch (NumberFormatException e) {
            System.out.println("Loi: " + e.getMessage());
        }

        System.out.println("Ket qua bieu thuc: " + A);

    }

    public static double tinhBT(int x, int y) throws ArithmeticException {
        double tu = x * 5 - y;
        int mau = 2 * x + 7 * y;
        
        if (x == 0 && y == 0 || mau == 0) 
            throw new ArithmeticException("Loi chia cho 0");
        
        if (tu < 0)
            throw new ArithmeticException("so am trong can");
        
        if (mau < 0)
            throw new ArithmeticException("so am trong can");
        
        double A = sqrt(tu / mau);

        return A;
    }

}
