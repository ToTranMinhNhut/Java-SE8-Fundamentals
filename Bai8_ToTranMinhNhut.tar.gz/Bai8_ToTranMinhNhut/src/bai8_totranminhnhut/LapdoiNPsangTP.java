/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author minhnhutvaio
 */
public class LapdoiNPsangTP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        String nNhiPhan = "";

        try {
            System.out.println("Nhap so nhi phan: ");
            nNhiPhan = input.readLine();
            
        } catch (NumberFormatException e) {
            System.out.println("Loi: " + e);
        }

        double j = 0;

        for (int i = 0; i < nNhiPhan.length(); i++) {
            if (nNhiPhan.charAt(i) == '1') {
                j = j + Math.pow(2, nNhiPhan.length() - 1 - i);
            }

        }
        System.out.println("nhi phan: " + j);
    }

}
