/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author minhnhutvaio
 */
public class LaptinhA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        int n = 0;
        float x = 0;

        try {
            System.out.println("Nhap n: ");
            n = Integer.parseInt(input.readLine());

            System.out.println("Nhap x: ");
            x = Float.parseFloat(input.readLine());
            
        } catch (NumberFormatException e) {
            System.out.println("Loi: " + e.getMessage());
        }
        
        double A = 0;

        if (n == 0) {
            A = 2;
        } else {
            double A1 = 1;
            double A2 = 1;

            for (int i = 1; i <= n; i++) {
                A1 *= (x * x + x + 1);
                A2 *= (x * x - x + 1);
                A = A1 + A2;
            }
        }

        System.out.println("A = " + A);
    }

}
