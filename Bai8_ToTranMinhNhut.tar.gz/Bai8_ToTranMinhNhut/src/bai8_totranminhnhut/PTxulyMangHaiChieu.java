/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author minhnhutvaio
 */
public class PTxulyMangHaiChieu {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        // Nhap mang hai chieu
        int n = 0, m = 0;

        try {
            System.out.println("Nhap so dong n: ");
            n = Integer.parseInt(input.readLine());

            System.out.println("Nhap so cot m: ");
            m = Integer.parseInt(input.readLine());

        } catch (NumberFormatException e) {
            System.out.println("Loi: " + e.getMessage());
        }

        int[][] arr = new int[n][m];
        nhapMangHaiChieu(n, m, arr);

        // Xuat mang hai chieu
        System.out.println("Mang hai chieu vua nhap: ");
        xuatMangHaiChieu(n, m, arr);

        int LonNhat = arr[0][0], NhoNhat = arr[0][0], am = 0;

        int soPhanTuLe = demPhanTuLe(n, m, arr);
        int soPhanTuChan = demPhanTuChan(n, m, arr);
        System.out.println("So phan tu chan: " + soPhanTuChan);
        System.out.println("So phan tu le:" + soPhanTuLe);

        float tbChan = tinhTBPhanTuChan(n, m, arr);
        System.out.println("Trung binh cac phan tu chan: " + tbChan);

        float tbLe = tinhTBPhanTuLe(n, m, arr);
        System.out.println("Trung binh cac phan tu le: " + tbLe);

        int lonNhat = timPhanTuLonNhat(n, m, arr);
        System.out.println("Phan tu lon nhat trong mang la: " + lonNhat);
        vitriPhanTuLonNhat(n, m, arr);

        int nhoNhat = timPhanTuNhoNhat(n, m, arr);
        System.out.println("Phan tu nho nhat trong mang la: " + nhoNhat);
        vitriPhanTuNhoNhat(n, m, arr);

        xuathienNhieuNhatCuaPhanTu(n, m, arr);

        // tim phan tu am trong mang
        timPhanTuAm(n, m, arr);
    }

    public static void nhapMangHaiChieu(int n, int m, int[][] arr) throws IOException {
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        if (n <= 0 || m <= 0) {
            throw new NegativeArraySizeException("Loi Mang khong co phan tu");
        }

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print("Nhap phan thu " + "[" + i + "]" + "[" + j + "]" + ": ");
                arr[i][j] = Integer.parseInt(input.readLine());
            }
        }
    }

    public static void xuatMangHaiChieu(int n, int m, int[][] arr) {

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print(arr[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static int demPhanTuChan(int n, int m, int[][] arr) {
        int chan = 0;

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {

                if ((arr[i][j] % 2) == 0) {
                    chan++;
                }
            }
        }

        return chan;
    }

    public static int demPhanTuLe(int n, int m, int[][] arr) {
        int le = 0;

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {

                if ((arr[i][j] % 2) != 0) {
                    le++;
                }
            }
        }

        return le;
    }

    public static float tinhTBPhanTuChan(int n, int m, int[][] arr) {

        int chan = demPhanTuChan(n, m, arr);
        int tongChan = 0;
        float TrungBinhChan = 0;
        
        if (chan > 0) {

            for (int i = 0; i < n; i++) {
                for (int j = 0; j < m; j++) {

                    if ((arr[i][j] % 2) == 0) {
                        tongChan += arr[i][j];
                    }
                }
            }

            TrungBinhChan = tongChan / chan;
        } else {
            throw new ArithmeticException("Loi chia cho 0");
        }

        return TrungBinhChan;
    }

    public static float tinhTBPhanTuLe(int n, int m, int[][] arr) {

        int le = demPhanTuLe(n, m, arr);
        int tongLe = 0;
        float TrungBinhLe = 0;

        if (le > 0) {

            for (int i = 0; i < n; i++) {
                for (int j = 0; j < m; j++) {

                    if ((arr[i][j] % 2) == 0) {
                        tongLe += arr[i][j];
                    }
                }
            }

            TrungBinhLe = tongLe / le;
        } else {
            throw new ArithmeticException("Chia cho 0");
        }

        return TrungBinhLe;
    }

    public static int timPhanTuLonNhat(int n, int m, int[][] arr) {
        int lonNhat = arr[0][0];

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {

                if (lonNhat <= arr[i][j]) {
                    lonNhat = arr[i][j];
                }
            }
        }

        return lonNhat;
    }

    public static int timPhanTuNhoNhat(int n, int m, int[][] arr) {
        int nhoNhat = arr[0][0];

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (arr[i][j] <= nhoNhat) {
                    nhoNhat = arr[i][j];
                }
            }
        }

        return nhoNhat;
    }

    public static void vitriPhanTuLonNhat(int n, int m, int[][] arr) {
        int lonNhat = timPhanTuLonNhat(n, m, arr);

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {

                if (lonNhat == arr[i][j]) {
                    System.out.println("phan tu lon nhat trong mang co vi tri la: dong " + i + " cot " + j);
                }
            }
        }
    }

    public static void vitriPhanTuNhoNhat(int n, int m, int[][] arr) {
        int nhoNhat = timPhanTuNhoNhat(n, m, arr);

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {

                if (nhoNhat == arr[i][j]) {
                    System.out.println("phan tu nho nhat trong mang co vi tri la: dong " + i + " cot " + j);
                }
            }
        }
    }

    public static int solanXuatHienCuaPhanTu(int n, int m, int[][] arr, int x) {
        int demXuatHien = 0;

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (arr[i][j] == x) {
                    demXuatHien++;
                }
            }
        }

        return demXuatHien;
    }

    public static void xuathienNhieuNhatCuaPhanTu(int n, int m, int[][] arr) {
        int soXHTam = 0;
        int soXHNN = solanXuatHienCuaPhanTu(n, m, arr, arr[0][0]);

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                soXHTam = solanXuatHienCuaPhanTu(n, m, arr, arr[i][j]);

                if (soXHTam > soXHNN) {
                    soXHNN = soXHTam;
                }
            }
        }

        for (int i = 0; i < n; i++) {
            int dem = 0;

            for (int j = 0; j < m; j++) {

                if (soXHNN == solanXuatHienCuaPhanTu(n, m, arr, arr[i][j])) {
                    dem++;
                    System.out.println("Phan tu xuat hien nhieu nhat: " + arr[i][j] + " tai dong " + i + " cot " + j);
                }
            }
        }
    }

    public static void timPhanTuAm(int n, int m, int[][] arr) {
        int am = 0;

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {

                if (arr[i][j] < 0) {
                    am++;
                }
            }
        }

        if (am != 0) {
            System.out.println("Ma tran co phan tu ");
        } else {
            System.out.println("Ma tran khong co phan tu am");
        }
    }

}
