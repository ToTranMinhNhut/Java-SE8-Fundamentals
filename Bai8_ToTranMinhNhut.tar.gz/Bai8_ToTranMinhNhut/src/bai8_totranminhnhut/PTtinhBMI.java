/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author minhnhutvaio
 */
public class PTtinhBMI {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException, Exception {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        double chieuCao = 0, canNang = 0;

        try {
            System.out.println("Nhap chieu cao (m): ");
            chieuCao = Double.parseDouble(input.readLine());

            System.out.println("Nhap can nang (kg): ");
            canNang = Double.parseDouble(input.readLine());

        } catch (NumberFormatException e) {
            System.out.println("Loi: " + e.getMessage());
        }

        double BMI = tinhBMI(canNang, chieuCao);
        danhGiaBMI(BMI);
    }

    public static double tinhBMI(double canNang, double chieuCao) throws ArithmeticException {

        if (chieuCao == 0) {
            throw new ArithmeticException("Loi chia cho 0");
        }

        if (chieuCao < 0) {
            throw new ArithmeticException("Loi chieu cao khong duoc am");
        }

        if (canNang < 0) {
            throw new ArithmeticException("Loi can nang khong duoc am");
        }

        double BMI = canNang / (chieuCao * chieuCao);
        return BMI;
    }

    public static void danhGiaBMI(double BMI) {

        if (BMI < 18.5) {
            System.out.println("BMI = " + BMI + " Ket luan : Ban Gay");
        } else if (BMI < 24.99) {
            System.out.println("BMI = " + BMI + " Ket luan : Ban binh thuong");
        } else {
            System.out.println("BMI = " + BMI + " Ket luan : Ban thua can");
        }
    }

}
