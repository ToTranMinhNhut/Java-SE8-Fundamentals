/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

/**
 *
 * @author minhnhutvaio
 */
public class PTxulyMaTranVuong {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        int m = 0;

        try {
            System.out.println("Nhap m");
            m = Integer.parseInt(input.readLine());
            
        } catch (NumberFormatException e) {
            System.out.println("Loi: " + e.getMessage());
        }
        
        // khoi tao ma tran A
        Random random = new Random();

        int[][] arr = new int[m][m];
        phatsinhMaTranVuong(m, arr);

        xuatMaTranVuong(m, arr);

        int tongDuongCheoChinh = tongDuongCheoChinh(m, arr);
        System.out.println("Tong duong cheo chinh: " + tongDuongCheoChinh);

        int soLNTrenDCC = soLNTrenDuongCheoChinh(m, arr);
        System.out.println("Phan tu lon nhat tren duong chinh: " + soLNTrenDCC);

        int soNNTrenDCC = soNNrenDuongCheoChinh(m, arr);
        System.out.println("Phan tu nho nhat tren duong cheo chinh: " + soNNTrenDCC);

        inSoNguyenTo(m, arr);

        // ma tran b
        int[][] arrB = new int[m][m];
        nhapMaTranVuong(m, arrB);

        // xuat ma tran b
        System.out.println("Ma tran vuong B: ");
        xuatMaTranVuong(m, arrB);

        kiemtraMTVDoiXung(m, arrB);

        // Ma tran C
        int[][] arrC = new int[m][m];
        khoitaoMaTranC(m, arr, arrB, arrC);

        System.out.println("Ma tran vuong C: ");
        xuatMaTranVuong(m, arrC);

        // kiem tra cot tang dan hoac giam dan
        System.out.println("Nhap vi trin cot k: <0 -> m>");
        int k = Integer.parseInt(input.readLine());

        cotTangHayGiamDan(m, arrC, k);
    }

    public static void phatsinhMaTranVuong(int m, int[][] arr) {
        
        if (m < 0) {
            throw new NegativeArraySizeException("Loi ma tran khong co phan tu");
        }
        
        Random random = new Random();

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < m; j++) {
                arr[i][j] = random.nextInt(20);
            }
        }
    }

    public static void xuatMaTranVuong(int m, int[][] arr) {

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print(arr[i][j] + "\t");
            }
            System.out.println();
        }
    }

    public static int tongDuongCheoChinh(int m, int[][] arr) {
        int tongDuongCheo = 0;

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < m; j++) {

                if (i == j) {
                    tongDuongCheo += arr[i][j];
                }
            }
        }

        return tongDuongCheo;
    }

    public static int soLNTrenDuongCheoChinh(int m, int[][] arr) {
        int lonNhat = arr[0][0];

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < m; j++) {

                if (i == j) {
                    if (arr[i][j] >= lonNhat) {
                        lonNhat = arr[i][j];
                    }
                }
            }
        }

        return lonNhat;
    }

    public static int soNNrenDuongCheoChinh(int m, int[][] arr) {
        int nhoNhat = arr[0][0];

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < m; j++) {

                if (i == j) {
                    if (arr[i][j] <= nhoNhat) {
                        nhoNhat = arr[i][j];
                    }
                }
            }
        }

        return nhoNhat;
    }

    public static void inSoNguyenTo(int m, int[][] arr) {

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < m; j++) {
                // so nguyen to
                int dem = 1;
                for (int k = 2; k <= arr[i][j]; k++) {
                    if ((arr[i][j] % k) == 0) {
                        dem++;
                    }
                }

                if (dem == 2) {
                    System.out.println("So nguyen to : " + arr[i][j] + " o dong " + i + " cot " + j);
                }
            }
        }
    }

    public static void nhapMaTranVuong(int m, int[][] arr) throws IOException {

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print("Nhap phan thu " + "[" + i + "]" + "[" + j + "]" + ": ");
                arr[i][j] = Integer.parseInt(input.readLine());
            }
        }
    }

    public static void kiemtraMTVDoiXung(int m, int[][] arr) {
        int doixung = 1;

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < m; j++) {
                if (arr[i][j] != arr[j][i]) {
                    doixung = 0;
                    break;
                }
            }
        }

        if (doixung == 0) {
            System.out.println("Ma tran khong doi xung ");
        } else {
            System.out.println("Ma tran doi xung");
        }
    }

    public static void khoitaoMaTranC(int m, int[][] arrA, int[][] arrB, int[][] arrC) {

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < m; j++) {
                arrC[i][j] = arrA[i][j] + arrB[i][j];
            }
        }
    }

    public static void cotTangHayGiamDan(int m, int[][] arr, int k) {
        int tangDan = 0, giamDan = 0;

        for (int i = 0; i < m - 1; i++) {
            for (int j = 0; j < m; j++) {

                int t = i + 1;

                if (j == k) {

                    if (arr[i][j] >= arr[t][j]) {
                        giamDan++;
                    }

                    if (arr[i][j] <= arr[t][j]) {
                        tangDan++;
                    }
                }
            }
        }

        if (tangDan == m - 1) {
            System.out.println("Cot " + k + " cua ma tran tang dan");
        } else if (giamDan == m - 1) {
            System.out.println("Cot " + k + " cua ma tran giam dan");
        } else {
            System.out.println("Cot " + k + " khong tang khong giam");
        }
    }

}
