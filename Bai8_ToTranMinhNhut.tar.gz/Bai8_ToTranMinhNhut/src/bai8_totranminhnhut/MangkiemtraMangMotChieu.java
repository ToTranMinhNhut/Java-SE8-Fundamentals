/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author minhnhutvaio
 */
public class MangkiemtraMangMotChieu {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        int n = 0;

        try {
            System.out.println("Nhap n: ");
            n = Integer.parseInt(input.readLine());

        } catch (NumberFormatException e) {
            System.out.println("Loi: " + e.getMessage());
        }
        
        if (n < 0) {
            throw new ArithmeticException("Loi Mang khong co phan tu");
        }
        
        int[] arr = new int[n];

        System.out.println("Nhap cac phan tu cua mang: ");
        for (int i = 0; i < n; i++) {
            arr[i] = Integer.parseInt(input.readLine());
        }

        for (int i = 0; i < n; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();

        // kiem tra mang tang dan
        int compare1 = 0;
        for (int i = 0; i < n - 1; i++) {
            int j = i + 1;
            if (arr[i] < arr[j]) {
                compare1++;
            }
        }

        if (compare1 != n - 1) {
            System.out.println("Mang vua nhap khong tang dan");
        } else {
            System.out.println("Mang vua nhap tang dang ");
        }

        // kiem tra mang giam dan;
        int compare2 = 0;
        for (int i = 0; i < n - 1; i++) {
            int j = i + 1;
            if (arr[i] > arr[j]) {
                compare2++;
            }
        }

        if (compare2 != n - 1) {
            System.out.println("Mang vua nhap khong giam dan");
        } else {
            System.out.println("Mang vua nhap giam dang ");
        }

        // in phan tu trong mang co tan cung la 6
        for (int i = 0; i < n; i++) {
            if ((arr[i] % 10) == 6) {
                System.out.println("so can tim la " + arr[i] + " o vi tri so " + i);
                break;
            }
        }
    }

}
