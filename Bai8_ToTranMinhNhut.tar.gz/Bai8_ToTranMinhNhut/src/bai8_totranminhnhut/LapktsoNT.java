/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author minhnhutvaio
 */
public class LapktsoNT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        int x = 0;

        try {
            System.out.println("Nhap x: ");
            x = Integer.parseInt(input.readLine());
            
        } catch (NumberFormatException e) {
            System.out.println("Loi: " + e);
        }
        
        int count = 1;

        for (int i = 2; i <= x; i++) {
            if ((x % i) == 0) {
                count++;
            }
        }

        if (count == 2) {
            System.out.println(x + " la so Nguyen to!");
        } else {
            System.out.println(x + " khong phai la so nguyen to");
        }
    }

}
