/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author minhnhutvaio
 */
public class LaptinhGTBT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        int n = 0;

        try {
            System.out.println("Nhap n: ");
            n = Integer.parseInt(input.readLine());
            
        } catch (NumberFormatException e) {
            System.out.println("Loi: " + e.getMessage());
        }
        
        double A = 0, B = 0, C = 1, D = 1;

        for (int i = 1; i <= n; i++) {

            // tong so le
            if ((i % 2) != 0) {
                A += i;
            }

            // tong so chan
            if ((i % 2) == 0) {
                B += i;
            }

            // tich cac so 1-n
            C *= i;

            // tich cac so chia het cho 3
            if ((i % 3) == 0) {
                D *= i;
            }
        }

        System.out.println("Ket qua A = " + A);
        System.out.println("Ket qua B = " + B);
        System.out.println("Ket qua C = " + C);
        System.out.println("Ket qua D = " + D);
    }

}
