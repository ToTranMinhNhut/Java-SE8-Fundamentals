/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author minhnhutvaio
 */
public class PTtinhGTBT {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        int n = 0;

        try {
            System.out.println("Nhap n: ");
            n = Integer.parseInt(input.readLine());

        } catch (NumberFormatException e) {
            System.out.println("Loi: " + e.getMessage());
        }

        double A = 0, B = 0, C = 1, D = 1;

        A = tongSoLe(n);
        B = tongSoLe(n);
        C = tichDaySo(n);
        D = tichSochiahetcho3(n);

        System.out.println("Ket qua tong so chan: A = " + A);
        System.out.println("Ket qua tong so le: B = " + B);
        System.out.println("Ket qua tich day so: C = " + C);
        System.out.println("Ket qua tich cac so chia het cho 3: D = " + D);
    }

    public static double tongSoLe(int n) {

        if (n < 0) {
            throw new ArithmeticException("Loi n khong duoc am");
        }

        double A = 0;
        for (int i = 1; i <= n; i++) {
            if ((i % 2) != 0) {
                A += i;
            }
        }

        return A;
    }

    public static double tongSoChan(int n) {
        if (n < 0) {
            throw new ArithmeticException("Loi n khong duoc am");
        }

        double B = 0;
        for (int i = 1; i <= n; i++) {
            if ((i % 2) == 0) {
                B += i;
            }
        }

        return B;
    }

    public static double tichDaySo(int n) {
        if (n < 0) {
            throw new ArithmeticException("Loi n khong duoc am");
        }

        double C = 1;
        for (int i = 1; i <= n; i++) {
            C *= i;
        }

        return C;
    }

    public static double tichSochiahetcho3(int n) {
        if (n < 0) {
            throw new ArithmeticException("Loi n khong duoc am");
        }

        double D = 1;

        for (int i = 1; i <= n; i++) {
            if ((i % 3) == 0) {
                D *= i;
            }
        }

        return D;
    }

}
