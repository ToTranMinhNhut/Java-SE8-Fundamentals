/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author minhnhutvaio
 */
public class PTtinhS {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        int n = 0;
        double x = 0;
        
        try {
            System.out.println("Nhap n: ");
            n = Integer.parseInt(input.readLine());

            System.out.println("Nhap x: ");
            x = Double.parseDouble(input.readLine());

        } catch (NumberFormatException e) {
            System.out.println("Loi: " + e.getMessage());
        }
        
        double S1 = 1;

        if (n != 0) {
            for (int i = 1; i <= n; i++) {
                S1 *= (x * x + 1);
            }
        }

        double S2 = tinhS(n, x);

        System.out.println("Canh viet thong thuong: S = (" + x + " * " + x + " + 1) mu " + n + " = " + S1);
        System.out.println("Canh viet ham: S = (" + x + " * " + x + " + 1) mu " + n + " = " + S2);
    }

    static double tinhS(int n, double x) {
        double S = 1;

        if (n != 0) {
            for (int i = 1; i <= n; i++) {
                S *= (x * x + 1);
            }
        }

        return S;
    }

}
