/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author minhnhutvaio
 */
public class LapdoiTPsangNP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        int nThapPhan = 0;

        try {
            System.out.println("Nhap n: ");
            nThapPhan = Integer.parseInt(input.readLine());
            
        } catch (NumberFormatException e) {
            System.out.println("Loi: " + e.getMessage());
        }
        
        String re = "";
        while (nThapPhan > 0) {
            int mod = nThapPhan % 2;
            re = re + mod;
            nThapPhan /= 2;
        }
        
        re = new StringBuffer(re).reverse().toString();
        System.out.println(re);
    }

}
