/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai5NgayThang {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
           
        System.out.println("Nhap thang: ");
        int thang = Integer.parseInt(input.readLine());
        
        
        if(thang >=1 && thang <=12){
            System.out.println("Thang " + thang + " hop le");
            
            System.out.println("Nhap ngay: ");
            int ngay = Integer.parseInt(input.readLine());
            
            switch (thang){
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 10:
                case 12:
                    if(ngay >= 1 && ngay <=31){
                        
                        System.out.println("Ngay " + ngay + " hop le");
                        
                        int ngayhomsau, ngayhomtruoc;
                        if(ngay < 31 && ngay >= 1){
                            
                            ngayhomsau = ngay+1 ;
                            System.out.println("Ngay hom sau la ngay " + ngayhomsau + " thang " + thang);
                            
                            System.out.println("Ngay hom truoc la ngay 1 thang " + (thang-1));
                        }else{
                            
                            System.out.println("Ngay hom sau la: 1/" + (thang+1));
                            
                            ngayhomtruoc = ngay-1 ;
                            System.out.println("Nguoi hom truoc la: " + ngayhomtruoc + "/" + thang);
                        }
                    }else
                        System.out.println("Ngay " + ngay + " khong hop le");
                    break;
                case 2:
                case 4:
                case 6:
                case 9:
                case 11:
                    if(ngay >=1 && ngay <=30){
                        
                        System.out.println("Ngay " + ngay + " hop le");
                    
                        int ngayhomsau, ngayhomtruoc;
                        if(ngay < 30 && ngay >= 1){
                            
                            ngayhomsau = ngay+1 ;
                            System.out.println("Ngay hom sau la ngay " + ngayhomsau + " thang " + thang);
                            
                            System.out.println("Ngay hom truoc la ngay 1 thang " + (thang-1));
                        }else{
                            System.out.println("Ngay hom sau la: 1/" + (thang+1));
                            
                            ngayhomtruoc = ngay-1 ;
                            System.out.println("Nguoi hom truoc la: " + ngayhomtruoc + "/" + thang);
                        }
            
                    }else
                        System.out.println("Ngay " + ngay + " khong hop le");
            }
        }else
            System.out.println("Thang" + thang + " khong hop le");
        
       
        
        
        
    }
    
}
