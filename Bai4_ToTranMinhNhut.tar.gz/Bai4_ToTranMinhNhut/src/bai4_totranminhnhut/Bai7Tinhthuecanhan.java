/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai7Tinhthuecanhan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        
        final int BACTHUE1 = 60;
        final int BACTHUE2 = 120;
        final int BACTHUE3 = 216;
        final int BACTHUE4 = 384;
        final int BACTHUE5 = 624;
        final int BACTHUE6 = 960;
        final double THUESUAT1 = 0.05;
        final double THUESUAT2 = 0.1;
        final double THUESUAT3 = 0.15;
        final double THUESUAT4 = 0.2;
        final double THUESUAT5 = 0.25;
        final double THUESUAT6 = 0.3;
        final double THUESUAT7 = 0.35;
       
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.println("Nhap tong thu nhap trong nam: ");
        double thunhap = Double.parseDouble(input.readLine());
        
        System.out.println("Nhap so nguoi phu thuoc: ");
        int nguoiphuthuoc = Integer.parseInt(input.readLine());
        
        double tiengiamtru = 9*12 + nguoiphuthuoc*3.6*12;
        double tienchiuthue = thunhap - tiengiamtru;
        double thuephainop = 0;
        if(tienchiuthue <= BACTHUE1)
            thuephainop = tienchiuthue * THUESUAT1 ;
        else if(tienchiuthue <= BACTHUE2)
            thuephainop = BACTHUE1*THUESUAT1 + (tienchiuthue-BACTHUE1)*THUESUAT2;
        else if(tienchiuthue <= BACTHUE3)
            thuephainop = BACTHUE1*THUESUAT1 + (BACTHUE2-BACTHUE1)*THUESUAT2 + (tienchiuthue-BACTHUE3)*THUESUAT3;
        else if(tienchiuthue <= BACTHUE4)
            thuephainop = BACTHUE1*THUESUAT1 + (BACTHUE2-BACTHUE1)*THUESUAT2 + (BACTHUE3-BACTHUE2)*THUESUAT3 + (tienchiuthue-BACTHUE3)*THUESUAT4;
        else if(tienchiuthue <= BACTHUE5)
            thuephainop =  BACTHUE1*THUESUAT1 + (BACTHUE2-BACTHUE1)*THUESUAT2 + (BACTHUE3-BACTHUE2)*THUESUAT3 +(BACTHUE4-BACTHUE3)*THUESUAT4 + (tienchiuthue-BACTHUE5)*THUESUAT5;
        else if (tienchiuthue <= BACTHUE6)
            thuephainop = BACTHUE1*THUESUAT1 + (BACTHUE2-BACTHUE1)*THUESUAT2 + (BACTHUE3-BACTHUE2)*THUESUAT3 + (BACTHUE4-BACTHUE3)*THUESUAT4 + (BACTHUE5-BACTHUE4)*THUESUAT5 + (tienchiuthue-BACTHUE5)*THUESUAT6;
        else
            thuephainop = BACTHUE1*THUESUAT1 + (BACTHUE2-BACTHUE1)*THUESUAT2 + (BACTHUE3-BACTHUE2)*THUESUAT3 + (BACTHUE4-BACTHUE3)*THUESUAT4 + (BACTHUE5-BACTHUE4)*THUESUAT5 + (tienchiuthue-BACTHUE6)*THUESUAT7;
        
        System.out.println("So tien giam tru: " + tiengiamtru + " trieu VND");
        System.out.println("So tien chiu thue: " + tienchiuthue + " trieu VND");
        System.out.println("Tien thue phai nop: " + thuephainop + " trieu VDN");
    }
    
}
