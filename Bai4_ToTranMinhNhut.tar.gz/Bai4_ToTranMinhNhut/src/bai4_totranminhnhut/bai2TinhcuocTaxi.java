/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai2TinhcuocTaxi {
   
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        
        final float KHOIDAU = (float) 0.8;
        final double PHAMVI30km = 30 ;
        
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.println("Nhap loai xe (4 hoac 7)");
        int soghe = Integer.parseInt(input.readLine());
        
        System.out.println("Nhap so km: ");
        float km = Float.parseFloat(input.readLine());
        
        double thanhtien = 0 ;
        if(soghe == 4){
           if(km <= KHOIDAU)
               thanhtien = km * 11.000;
           else if(km <= PHAMVI30km)
                    thanhtien = KHOIDAU*11.000 + (km-KHOIDAU)*16.500;
           else
               thanhtien = KHOIDAU*11.000 + (PHAMVI30km-KHOIDAU)*16.500 + (km-PHAMVI30km)*12.400;
        }else if (soghe == 7){
            if(km <= KHOIDAU)
               thanhtien = km * 11.000;
           else if(km <= PHAMVI30km)
                    thanhtien = KHOIDAU*11.000 + (km-KHOIDAU)*17.000;
                else
                    thanhtien = KHOIDAU*11.000 + (PHAMVI30km-KHOIDAU)*17.000 + (km-PHAMVI30km)*14.400;
        }
        System.out.println("Thanh tien: " + thanhtien + "VND");
    }
    
}
