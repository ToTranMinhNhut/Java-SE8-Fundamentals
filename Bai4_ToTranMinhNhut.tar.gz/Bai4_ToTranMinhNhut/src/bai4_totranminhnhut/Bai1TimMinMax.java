/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai1TimMinMax {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader (new InputStreamReader(System.in));
        
        System.out.println("Nhap a: ");
        int a = Integer.parseInt(input.readLine());
        
        System.out.println("Nhap b: ");
        int b = Integer.parseInt(input.readLine());
        
        System.out.println("nhap c");
        int c =Integer.parseInt(input.readLine());
        
        System.out.println("Nhap d: ");
        int d = Integer.parseInt(input.readLine());
        
        int max = a, min = a ;
        if(max < b)
            max = b;
        else 
            min = b;
        
        if (max < c)
            max = c;
        else
            min = c;
        
        if(max < d ) 
            max = d;
        else
            min = d;
       
        System.out.println("So lon nhat: " + max);
        System.out.println("So nho nhat: " + min);
        
        
    }
    
}
