/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvienietdo
 */
public class bai6Tinhnhietdo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.println("Nhap don vi C hoac F: ");
        String donvi = input.readLine();
        
        System.out.println("Nhap nhiet do: ");
        float nhietdo = Float.parseFloat(input.readLine());
        
        float nhietdotam = 0;
        if(donvi.compareTo("f")==0){
            nhietdotam = 5*(nhietdo-32)/9;
            System.out.println(nhietdo + "F = " + nhietdotam + "C");            
        }else if(donvi.compareTo("c") == 0){
            nhietdotam = nhietdo*9/5 + 32;
            System.out.println(nhietdo + "C = " + nhietdotam + "F");        
        }

    }
    
}
