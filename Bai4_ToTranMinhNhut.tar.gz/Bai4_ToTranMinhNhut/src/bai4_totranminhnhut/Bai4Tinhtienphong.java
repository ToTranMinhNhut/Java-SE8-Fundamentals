/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai4Tinhtienphong {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        final long GIALOAI1 = 126000;
        final long GIALOAI2= 1550000;
        final long GIALOAI3 = 1830000;
        final long GIALOAI4 = 1830000;
        final long GIALOAI5 = 2120000;
        final long GIALOAI6 = 2120000;
        final long GIALOAI7 = 2540000;
        final long GIALOAI8 = 4800000;
        
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhap loai phong: ");
        int loaiphong = Integer.parseInt(input.readLine());
        
        System.out.println("Nhap so dem: ");
        int sodem = Integer.parseInt(input.readLine());
        long thanhtien = 0;
        
        if(loaiphong == 1){
            if(sodem == 1)
                thanhtien = GIALOAI1 ;
            else if(sodem >=2 && sodem <=3)
                thanhtien = (long) (GIALOAI1*sodem - GIALOAI1*sodem*0.25);
                else
                    thanhtien = (long) (GIALOAI1*sodem - GIALOAI1*sodem*0.3);
        
        }else if(loaiphong == 2){
            if(sodem == 1)
                thanhtien = GIALOAI2 ;
            else if(sodem >=2 && sodem <=3)
                thanhtien = (long) (GIALOAI2*sodem - GIALOAI2*sodem*0.25);
                else
                    thanhtien = (long) (GIALOAI2*sodem - GIALOAI2*sodem*0.3);
        
        }else if(loaiphong == 3){
            if(sodem == 1)
                thanhtien = GIALOAI3 ;
            else if(sodem >=2 && sodem <=3)
                thanhtien = (long) (GIALOAI3*sodem - GIALOAI3*sodem*0.25);
                else
                    thanhtien = (long) (GIALOAI3*sodem - GIALOAI3*sodem*0.3);
        
        }else if(loaiphong == 4){
            if(sodem == 1)
                thanhtien = GIALOAI4 ;
            else if(sodem >=2 && sodem <=3)
                thanhtien = (long) (GIALOAI4*sodem - GIALOAI4*sodem*0.25);
                else
                    thanhtien = (long) (GIALOAI4*sodem - GIALOAI4*sodem*0.3);
        
        }else if(loaiphong == 5){
            if(sodem == 1)
                thanhtien = GIALOAI5 ;
            else if(sodem >=2 && sodem <=3)
                thanhtien = (long) (GIALOAI5*sodem - GIALOAI5*sodem*0.25);
                else
                    thanhtien = (long) (GIALOAI5*sodem - GIALOAI5*sodem*0.3);
        
        }else if(loaiphong == 6){
            if(sodem == 1)
                thanhtien = GIALOAI6 ;
            else if(sodem >=2 && sodem <=3)
                thanhtien = (long) (GIALOAI6*sodem - GIALOAI6*sodem*0.25);
                else
                    thanhtien = (long) (GIALOAI6*sodem - GIALOAI6*sodem*0.3);
        
        }else if(loaiphong == 7){
            if(sodem == 1)
                thanhtien = GIALOAI7 ;
            else if(sodem >=2 && sodem <=3)
                thanhtien = (long) (GIALOAI7*sodem - GIALOAI7*sodem*0.25);
                else
                    thanhtien = (long) (GIALOAI7*sodem - GIALOAI7*sodem*0.3);
        
        }else if(loaiphong == 8){
            if(sodem == 1)
                thanhtien = GIALOAI8 ;
            else if(sodem >=2 && sodem <=3)
                thanhtien = (long) (GIALOAI8*sodem - GIALOAI8*sodem*0.25);
                else
                    thanhtien = (long) (GIALOAI8*sodem - GIALOAI8*sodem*0.3);
        }
        System.out.println("Thanh tien = " + thanhtien + "VND");
    }
    
}
