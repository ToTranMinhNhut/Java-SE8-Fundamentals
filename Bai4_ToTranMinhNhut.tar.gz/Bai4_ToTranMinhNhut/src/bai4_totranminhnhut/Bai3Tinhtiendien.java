/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai3Tinhtiendien {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        final int BAC1 = 50;
        final int BAC2 = 100;
        final int BAC3 = 200;
        final int BAC4 = 300;
        final int BAC5 = 400;
        final float GIA1 = (float) 1.388, GIA2 = (float) 1.433, GIA3 = (float)1.660, GIA4 = (float) 2.082, GIA5 = (float)2.324, GIA6 = (float) 2.399;
        
        
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Nhap so kw tieu thu: ");
        int kw = Integer.parseInt(input.readLine());
        
        double thanhtien = 0;
        if(kw <= BAC1)
            thanhtien = kw*BAC1 ;
        else if(kw <= BAC2)
            thanhtien = BAC1*GIA1 + (kw-BAC1)*GIA2;
        else if(kw <= BAC3)
            thanhtien = BAC1*GIA1 + (BAC2-BAC1)*GIA2 + (kw-BAC2)*GIA3;
        else if(kw <= BAC4)
            thanhtien = BAC1*GIA1 + (BAC2-BAC1)*GIA2 + (BAC3-BAC2)*GIA3 + (kw-BAC3)*GIA4;
        else if(kw <= BAC5)
            thanhtien = BAC1*GIA1 + (BAC2-BAC1)*GIA2 + (BAC3-BAC2)*GIA3 + (BAC4-BAC3)*GIA4 + (kw-BAC4)*GIA5;
        else
            thanhtien = BAC1*GIA1 + (BAC2-BAC1)*GIA2 + (BAC3-BAC2)*GIA3 + (BAC4-BAC3)*GIA4+ (BAC5-BAC4)*GIA5 + (kw-BAC5)*GIA6;
        
        System.out.println("Thanh tien = " + thanhtien);
                    
    }
    
}
