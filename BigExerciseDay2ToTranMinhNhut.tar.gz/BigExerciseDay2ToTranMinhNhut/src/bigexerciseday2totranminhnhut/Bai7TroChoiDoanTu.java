/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

/**
 *
 * @author hocvien
 */
public class Bai7TroChoiDoanTu {

    /**
     * @param args the command line arguments
     */
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) throws UnsupportedEncodingException, IOException {
        // TODO code application logic here

        String[] mang = {"program", "developer", "testing", "coder", "algorithm", "bug", "console", "user", "system", "application"};

        System.out.println("Tro choi co " + mang.length + " chu");

        troChoi(mang);
    }

    static void troChoi(String[] mang) throws IOException {
        boolean kt = true;

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        int viTri = 0;
        while (kt) {
            try {
                System.out.println("nhap vi tri chu muon doan 0-9");
                viTri = Integer.parseInt(input.readLine());
            } catch (NumberFormatException num) {
                kt = true;
                System.out.println("Loi nhap sai so: " + num.toString());
                continue;
            }
            if (viTri < 0 || viTri > mang.length) {
                System.out.println("Nhap lai ");
                continue;
            }
            kt = false;
        }

        String chuoi = mang[viTri];
        System.out.println("Tu co " + chuoi.length() + " ki tu");

        char[] tuAn = new char[chuoi.length()];
        for (int i = 0; i < tuAn.length; i++) {
            tuAn[i] = chuoi.charAt(i);
        }

        char[] hienThi = new char[chuoi.length()];

        String tu = "";

        boolean thang = false;
        kt = true;
        int soLanChoi = 1;

        while (!thang) {
            while (kt) {
                System.out.println("Lan: " + soLanChoi);
                System.out.println("Nhap chu ban muon doan: ");
                tu = input.readLine();
                if (tu.length() > 1) {
                    System.out.println("nhap qua so luong ki tu");
                    continue;
                }

                int dem = 0;
                for (int i = 0; i < tuAn.length; i++) {
                    if (tuAn[i] == tu.charAt(0)) {
                        hienThi[i] = tuAn[i];
                        dem++;
                    }
                }

                if (dem > 0) {
                    System.out.println("Co " + dem + " ki tu " + tu.charAt(0));
                } else {
                    System.out.println("ban da doan sai");
                }

                for (int i = 0; i < hienThi.length; i++) {
                    System.out.print(hienThi[i]);
                }

                System.out.println();
                int diem = 0;

                for (int i = 0; i < hienThi.length; i++) {
                    if (hienThi[i] == tuAn[i]) {
                        diem++;
                    }
                }

                if (diem == tuAn.length) {
                    kt = false;
                    thang = true;
                }
                soLanChoi++;
            }
        }

        if (thang) {
            System.out.println("Ban da tim ra chu " + mang[viTri] + " sau " + soLanChoi + " doan ");
        }
    }

}
