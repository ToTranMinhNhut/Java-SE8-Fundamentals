/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

/**
 *
 * @author hocvien
 */
public class Bai2TienNuoc {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws UnsupportedEncodingException, IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in, "UTF-8"));
        try {
            System.out.println("Nhap so luong: ");
            double luongNuoc = Double.parseDouble(input.readLine());

            System.out.println("Chon: <1><Doi tuong sinh hoat> <2><Doi tuong khong sinh hoat>");
            int doiTuong = Integer.parseInt(input.readLine());

            int soNguoi = 0, loaiDung = 0;
            double tienNuocTruocThue = 0, tienThue = 0, tienPhi = 0, tongTienNuoc = 0;

            if (doiTuong == 1) {
                System.out.println("Nhap so nguoi cua ho gia dinh: ");
                soNguoi = Integer.parseInt(input.readLine());

                tienNuocTruocThue = tinhTienNuocDTSinhHoat(luongNuoc, soNguoi) * soNguoi;
                tienThue = tienNuocTruocThue * 0.05;
                tienPhi = tienNuocTruocThue * 0.1;
                tongTienNuoc = tienNuocTruocThue + tienThue + tienPhi;

                System.out.println("Tong so nuoc: " + luongNuoc);
                System.out.println("Tien nuoc khong thue va phi: " + tienNuocTruocThue);
                System.out.println("Tien thue: " + tienThue);
                System.out.println("Tien phi: " + tienPhi);
                System.out.println("Tong tien: " + tongTienNuoc);

            } else if (doiTuong == 2) {
                System.out.println("Chon: <1><Don vi san xuat> <2> <Co quan, doan the, HC su ngiep> <3><Don vi kinh doanh, dich vu>");
                loaiDung = Integer.parseInt(input.readLine());

                tienNuocTruocThue = tinhTienNuocDTKhongSinhHoat(luongNuoc, loaiDung);
                tienThue = tienNuocTruocThue * 0.05;
                tienPhi = tienNuocTruocThue * 0.1;
                tongTienNuoc = tienNuocTruocThue + tienThue + tienPhi;

                System.out.println("Tong so nuoc: " + luongNuoc);
                System.out.println("Tien nuoc khong thue va phi: " + tienNuocTruocThue);
                System.out.println("Tien thue: " + tienThue);
                System.out.println("Tien phi: " + tienPhi);
                System.out.println("Tong tien: " + tongTienNuoc);
            }
        } catch (NumberFormatException e) {
            System.out.println("loi nhap sai du lieu");
        }
    }

    public static double tinhTienNuocDTSinhHoat(double luongNuoc, int soNguoi) {
        double tienNuoc = 0;

        double luongNuoc1Nguoi = luongNuoc / soNguoi;
        double mucNuoc1 = 4, mucNuoc2 = 6;
        if (luongNuoc1Nguoi > 0 && luongNuoc1Nguoi <= mucNuoc1) {
            tienNuoc = 5300 * luongNuoc1Nguoi;
        } else if (luongNuoc1Nguoi <= mucNuoc2) {
            tienNuoc = 4 * 5300 + (luongNuoc1Nguoi - 4) * 10200;
        } else {
            tienNuoc = 4 * 5300 + 10200 * 2 + (luongNuoc1Nguoi - 6) * 11400;
        }
        return tienNuoc;
    }

    public static double tinhTienNuocDTKhongSinhHoat(double luongNuoc, int loaiDung) {
        double tienNuoc = 0;

        if (loaiDung == 1) {
            tienNuoc = 9600 * luongNuoc;
        } else if (loaiDung == 2) {
            tienNuoc = 10300 * luongNuoc;
        } else if (loaiDung == 3) {
            tienNuoc = 16900 * luongNuoc;
        }
        return tienNuoc;
    }

}
