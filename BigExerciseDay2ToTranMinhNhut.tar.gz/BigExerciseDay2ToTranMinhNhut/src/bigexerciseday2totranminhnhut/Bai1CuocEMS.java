/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

/**
 *
 * @author hocvien
 */
public class Bai1CuocEMS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws UnsupportedEncodingException, IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in, "UTF-8"));
        try {
            System.out.println("Nhap trong luong buu pham <gr>: ");
            double trongLuong = Double.parseDouble(input.readLine());

            System.out.println("Chon hinh thuc gui <1> <2> <3>: ");
            int hinhThucGui = Integer.parseInt(input.readLine());

            System.out.println("Chon: <1><Noi tinh> <2><Lien tinh>");
            int ems = Integer.parseInt(input.readLine());

            int vung = 0, khoangCach = 0;
            if (ems == 2) {
                System.out.println("Chon vung: <1> <2> <3>");
                vung = Integer.parseInt(input.readLine());

                if (vung == 2) {
                    System.out.println("Chon: <1><Da Nang->Ha Noi hoac HCM va nguoc lai> <2><Ha Noi->HCM va nguoc lai>");
                    khoangCach = Integer.parseInt(input.readLine());
                }
            }
            double tienCuoc = tinhCuoc(trongLuong, hinhThucGui, ems, vung, khoangCach);
            System.out.println("Tien Cuoc: " + tienCuoc);
        } catch (NumberFormatException n) {
            System.out.println("loai nhap sai du lieu");
        }

    }

    public static double tinhCuoc(double khoiLuong, int hinhThuc, int ems, int vung, int khoangCach) {
        double tienCuoc = 0;
        double mucKhoiLuong1 = 50, mucKhoiLuong2 = 100, mucKhoiLuong3 = 250, mucKhoiLuong4 = 500, mucKhoiLuong5 = 1000, mucKhoiLuong6 = 1500, mucKhoiLuong7 = 2000;

        switch (hinhThuc) {
            case 1:
                if (ems == 1) {
                    if (khoiLuong > 0 && khoiLuong <= mucKhoiLuong1) {
                        tienCuoc = 8000;
                    } else if (khoiLuong <= mucKhoiLuong2) {
                        tienCuoc = 8000;
                    } else if (khoiLuong <= mucKhoiLuong3) {
                        tienCuoc = 10000;
                    } else if (khoiLuong <= mucKhoiLuong4) {
                        tienCuoc = 12500;
                    } else if (khoiLuong <= mucKhoiLuong5) {
                        tienCuoc = 15000;
                    } else if (khoiLuong <= mucKhoiLuong6) {
                        tienCuoc = 18000;
                    } else if (khoiLuong < mucKhoiLuong7) {
                        tienCuoc = 21000;
                    } else {
                        double khoiLuongVuot11 = khoiLuong - mucKhoiLuong7;
                        tienCuoc = 21000 + 1600 * Math.ceil(khoiLuongVuot11 / 500);
                    }
                } else if (ems == 2) {
                    if (vung == 1) {

                        if (khoiLuong > 0 && khoiLuong <= mucKhoiLuong1) {
                            tienCuoc = 8500;
                        } else if (khoiLuong <= mucKhoiLuong2) {
                            tienCuoc = 12500;
                        } else if (khoiLuong <= mucKhoiLuong3) {
                            tienCuoc = 16500;
                        } else if (khoiLuong <= mucKhoiLuong4) {
                            tienCuoc = 23500;
                        } else if (khoiLuong <= mucKhoiLuong5) {
                            tienCuoc = 33000;
                        } else if (khoiLuong <= mucKhoiLuong6) {
                            tienCuoc = 40000;
                        } else if (khoiLuong < mucKhoiLuong7) {
                            tienCuoc = 48500;
                        } else {
                            double khoiLuongVuot121 = khoiLuong - mucKhoiLuong7;
                            tienCuoc = 48500 + 3800 * Math.ceil(khoiLuongVuot121 / 500);
                        }

                    } else if (vung == 2) {
                        if (khoangCach == 1) {

                            if (khoiLuong > 0 && khoiLuong <= mucKhoiLuong1) {
                                tienCuoc = 9500;
                            } else if (khoiLuong <= mucKhoiLuong2) {
                                tienCuoc = 13500;
                            } else if (khoiLuong <= mucKhoiLuong3) {
                                tienCuoc = 20000;
                            } else if (khoiLuong <= mucKhoiLuong4) {
                                tienCuoc = 26500;
                            } else if (khoiLuong <= mucKhoiLuong5) {
                                tienCuoc = 38500;
                            } else if (khoiLuong <= mucKhoiLuong6) {
                                tienCuoc = 49500;
                            } else if (khoiLuong < mucKhoiLuong7) {
                                tienCuoc = 59500;
                            } else {
                                double khoiLuongVuot1221 = khoiLuong - mucKhoiLuong7;
                                tienCuoc = 59500 + 8500 * Math.ceil(khoiLuongVuot1221 / 500);
                            }
                        } else if (khoangCach == 2) {

                            if (khoiLuong > 0 && khoiLuong <= mucKhoiLuong1) {
                                tienCuoc = 9500;
                            } else if (khoiLuong <= mucKhoiLuong2) {
                                tienCuoc = 13500;
                            } else if (khoiLuong <= mucKhoiLuong3) {
                                tienCuoc = 21500;
                            } else if (khoiLuong <= mucKhoiLuong4) {
                                tienCuoc = 28000;
                            } else if (khoiLuong <= mucKhoiLuong5) {
                                tienCuoc = 40500;
                            } else if (khoiLuong <= mucKhoiLuong6) {
                                tienCuoc = 52500;
                            } else if (khoiLuong < mucKhoiLuong7) {
                                tienCuoc = 63500;
                            } else {
                                double khoiLuongVuot1222 = khoiLuong - mucKhoiLuong7;
                                tienCuoc = 63500 + 8500 * Math.ceil(khoiLuongVuot1222 / 500);
                            }
                        }
                    } else if (vung == 3) {

                        if (khoiLuong > 0 && khoiLuong <= mucKhoiLuong1) {
                            tienCuoc = 10000;
                        } else if (khoiLuong <= mucKhoiLuong2) {
                            tienCuoc = 14000;
                        } else if (khoiLuong <= mucKhoiLuong3) {
                            tienCuoc = 22500;
                        } else if (khoiLuong <= mucKhoiLuong4) {
                            tienCuoc = 29500;
                        } else if (khoiLuong <= mucKhoiLuong5) {
                            tienCuoc = 43500;
                        } else if (khoiLuong <= mucKhoiLuong6) {
                            tienCuoc = 55500;
                        } else if (khoiLuong < mucKhoiLuong7) {
                            tienCuoc = 67500;
                        } else {
                            double khoiLuongVuot123 = khoiLuong - mucKhoiLuong7;
                            tienCuoc = 67500 + 9500 * Math.ceil(khoiLuongVuot123 / 500);
                        }
                    }
                }
                break;
            case 2:
                double mucKhoiLuongHT2 = 2000;
                if (ems == 1) {
                    if (khoiLuong > 0 && khoiLuong <= mucKhoiLuongHT2) {
                        tienCuoc = 50000;
                    } else {
                        double KhoiLuongVuot21 = khoiLuong - mucKhoiLuongHT2;
                        tienCuoc = 50000 + 5000 * Math.ceil(KhoiLuongVuot21 / 500);
                    }
                } else if (ems == 2) {

                    if (vung == 1) {
                        if (khoiLuong > 0 && khoiLuong <= mucKhoiLuongHT2) {
                            tienCuoc = 70000;
                        } else {
                            double KhoiLuongVuot221 = khoiLuong - mucKhoiLuongHT2;
                            tienCuoc = 70000 + 7000 * Math.ceil(KhoiLuongVuot221 / 500);
                        }
                    } else if (vung == 2) {

                        if (khoangCach == 1) {

                            if (khoiLuong > 0 && khoiLuong <= mucKhoiLuongHT2) {
                                tienCuoc = 110000;
                            } else {
                                double KhoiLuongVuot2221 = khoiLuong - mucKhoiLuongHT2;
                                tienCuoc = 110000 + 12000 * Math.ceil(KhoiLuongVuot2221 / 500);
                            }
                        } else if (khoangCach == 2) {

                            if (khoiLuong > 0 && khoiLuong <= mucKhoiLuongHT2) {
                                tienCuoc = 130000;
                            } else {
                                double KhoiLuongVuot2222 = khoiLuong - mucKhoiLuongHT2;
                                tienCuoc = 130000 + 20000 * Math.ceil(KhoiLuongVuot2222 / 500);
                            }
                        }
                    }
                }
                break;
            case 3:
                double mucKhoiLuongHT3 = 2000;

                if (ems == 1) {
                    if (khoiLuong > 0 && khoiLuong <= mucKhoiLuongHT3) {
                        tienCuoc = 50000;
                    } else {
                        double KhoiLuongVuot31 = khoiLuong - mucKhoiLuongHT3;
                        tienCuoc = 50000 + 5000 * Math.ceil(KhoiLuongVuot31 / 500);
                    }
                } else if (ems == 2) {
                    if (vung == 1) {

                        if (khoiLuong > 0 && khoiLuong <= mucKhoiLuongHT3) {
                            tienCuoc = 70000;
                        } else {
                            double KhoiLuongVuot321 = khoiLuong - mucKhoiLuongHT3;
                            tienCuoc = 70000 + 7000 * Math.ceil(KhoiLuongVuot321 / 500);
                        }
                    } else if (vung == 2) {
                        if (khoangCach == 1) {
                            if (khoiLuong > 0 && khoiLuong <= mucKhoiLuongHT3) {
                                tienCuoc = 85000;
                            } else {
                                double KhoiLuongVuot3221 = khoiLuong - mucKhoiLuongHT3;
                                tienCuoc = 85000 + 10000 * Math.ceil(KhoiLuongVuot3221 / 500);
                            }
                        } else if (khoangCach == 2) {
                            if (khoiLuong > 0 && khoiLuong <= mucKhoiLuongHT3) {
                                tienCuoc = 100000;
                            } else {
                                double KhoiLuongVuot3222 = khoiLuong - mucKhoiLuongHT3;
                                tienCuoc = 100000 + 12000 * Math.ceil(KhoiLuongVuot3222 / 500);
                            }
                        }
                    } else if (vung == 3) {

                        if (khoiLuong > 0 && khoiLuong <= mucKhoiLuongHT3) {
                            tienCuoc = 110000;
                        } else {
                            double KhoiLuongVuot323 = khoiLuong - mucKhoiLuongHT3;
                            tienCuoc = 110000 + 15000 * Math.ceil(KhoiLuongVuot323 / 500);
                        }
                    }
                }
                break;
            default:
                break;
        }
        return tienCuoc;
    }
}
