/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2totranminhnhut;

/**
 *
 * @author hocvien
 */
public class Bai5BanCo {

    public static final int CANH = 8;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        veBanCo();
    }

    public static void veBanCo() {
        for (int i = 1; i < 9; i++) {
            System.out.println(" ------------------------------------------------------");

            if (i % 2 != 0) {
                for (int j = 1; j < 9; j++) {
                    if (j % 2 != 0) {
                        System.out.print(" | W | ");
                    } else {
                        System.out.print(" | B | ");
                    }
                }
            } else {
                for (int j = 1; j < 9; j++) {
                    if (j % 2 != 0) {
                        System.out.print(" | B | ");
                    } else {
                        System.out.print(" | W | ");
                    }
                }
            }
            System.out.println();
        }
        System.out.println(" ------------------------------------------------------");

    }

}
