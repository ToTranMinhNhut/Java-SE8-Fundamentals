/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2totranminhnhut;

/**
 *
 * @author hocvien
 */
public class Bai5BanCo {

    public static final int CANH = 8;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        String[][] banCo = new String[CANH][CANH];
        veBanCo(banCo);
        inBanCo(banCo);
    }

    public static void veBanCo(String[][] banCo) {
        for (int i = 0; i < banCo.length; i++) {
            for (int j = 0; j < banCo.length; j++) {
                if (i == 0) {
                    if (j % 2 != 0) {
                        banCo[i][j] = "B";
                    } else {
                        banCo[i][j] = "W";
                    }
                } else if (j == 0) {
                    if (i % 2 != 0) {
                        banCo[i][j] = "B";
                    } else {
                        banCo[i][j] = "W";
                    }
                } else if (i % 2 != 0 && j % 2 != 0) {
                    banCo[i][j] = "B";
                } else {
                    banCo[i][j] = "W";
                }
            }

        }
    }

    public static void inBanCo(String[][] banCo) {

        for (int i = 0; i < banCo.length; i++) {
            System.out.println(" ------------------------------------------------------");
            for (int j = 0; j < banCo.length; j++) {
                System.out.print(" | " + banCo[i][j] + " | ");
            }
            System.out.println();
        }
        System.out.println(" ------------------------------------------------------");

    }

}
