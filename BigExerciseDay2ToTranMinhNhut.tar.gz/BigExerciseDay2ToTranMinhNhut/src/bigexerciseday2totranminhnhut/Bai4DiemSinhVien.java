/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

/**
 *
 * @author hocvien
 */
public class Bai4DiemSinhVien {

    public static final int DIEM0 = 0, DIEM10 = 10;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws UnsupportedEncodingException, IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in, "UTF-8"));

        System.out.println("Nhap so luong sinh vien:");
        int n = Integer.parseInt(input.readLine());

        double[] diem = new double[n];
        nhapDiemSinhVien(diem, n);

        double diemTB = tinhDiemTrungBinh(diem, n);
        System.out.println("Diem trung binh cua " + n + " sinh vien la: " + diemTB);
        
        double diemCaoNhat = timDiemCaoNhat(diem, n);
        System.out.println("Diem cao nhat trong " + n + " sinh vien la: " + diemCaoNhat);
        double diemThapNhat = timDiemThapNhat(diem, n);
        System.out.println("Diem thap nhat trong " + n + " sinh vien la: " + diemThapNhat);
    }

    public static void nhapDiemSinhVien(double[] diem, int n) throws UnsupportedEncodingException, IOException {
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in, "UTF-8"));

        for (int i = 0; i < n; i++) {
            do {
                System.out.println("Diem cua sinh vien thu: " + (i + 1));
                diem[i] = Double.parseDouble(input.readLine());
            } while (diem[i] < DIEM0 || diem[i] > DIEM10);
        }
    }

    public static double tinhDiemTrungBinh(double[] diem, int n) {
        double diemTong = 0;

        for (int i = 0; i < n; i++) {
            diemTong += diem[i];
        }
        double diemTB = diemTong / n;

        return diemTB;
    }
    
    public static double timDiemCaoNhat(double[] diem, int n) {
        double diemCaoNhat = diem[0];

        for (int i = 0; i < n; i++) {
            if (diemCaoNhat <= diem[i]) {
                diemCaoNhat = diem[i];
            }
        }
        return diemCaoNhat;
    }

    public static double timDiemThapNhat(double[] diem, int n) {
        double diemThapNhat = diem[0];

        for (int i = 0; i < n; i++) {
            if (diemThapNhat >= diem[i]) {
                diemThapNhat = diem[i];
            }
        }
        return diemThapNhat;
    }
    
    
}
