/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2totranminhnhut;

/**
 *
 * @author hocvien
 */
public class Bai6MaTranChuoi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("a");
        vehinhA();

        System.out.println("b");
        vehinhB();

        System.out.println("c");
        vehinhC();

        System.out.println("d");
        vehinhD();

        System.out.println("e");
        vehinhE();

        System.out.println("f");
        vehinhF();

        System.out.println("g");
        vehinhG();
    }

    public static void vehinhA() {
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 11; j++) {
                if (i <= j && j <= (10 - i)) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.println();
        }
    }

    public static void vehinhB() {
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 11; j++) {
                if (j >= (5 - i) && j <= (5 + i)) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.println();
        }
    }

    public static void vehinhC() {
        for (int i = 0; i < 12; i++) {
            for (int j = 0; j < 11; j++) {
                if (j >= (5 - i) && j <= (5 + i) && i < 6) {
                    System.out.print("# ");
                } else if (j >= (i - 5) && j <= (15 - i) && i > 5) {
                    System.out.print("# ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.println();
        }
    }

    public static void vehinhD() {
        for (int i = 1; i <= 8; i++) {
            for (int j = 1; j <= 8; j++) {
                if (i >= j) {
                    System.out.print(j + " ");
                }
            }
            System.out.println();
        }
    }

    public static void vehinhE() {
        int dem = 0;
        for (int i = 1; i <= 8; i++) {
            for (int j = 1; j <= 8; j++) {
                if (i > j) {
                    System.out.print("  ");
                } else {
                    System.out.print(j - dem + " ");
                }
            }
            System.out.println();
            dem++;
        }
    }

    public static void vehinhF() {
        int dem = 0;
        for (int i = 1; i <= 8; i++) {
            dem = 1;
            for (int j = 1; j <= 8; j++) {
                if (i + j <= 8) {
                    System.out.print("  ");
                    dem++;
                } else {
                    System.out.print((i + j - dem) + " ");
                    dem += 2;
                }
            }
            System.out.println();
        }
    }

    public static void vehinhG() {
        int dem = 0;
        dem = 7;
        int tam = 0;
        for (int i = 1; i <= 8; i++) {
            tam = dem;
            for (int j = 1; j <= 8; j++) {
                if (i <= j) {
                    System.out.print((j + tam) + " ");
                    tam -= 2;
                }

            }
            System.out.println();
            dem -= 2;
        }
    }
}
