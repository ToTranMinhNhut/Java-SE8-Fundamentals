/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

/**
 *
 * @author hocvien
 */
public class Bai3Mang2Chieu {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws UnsupportedEncodingException, IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in, "UTF-8"));

        System.out.println("Nhap co dong n: ");
        int n = Integer.parseInt(input.readLine());

        System.out.println("Nhap so cot m: ");
        int m = Integer.parseInt(input.readLine());

        int[][] arr = new int[n][m];
        nhapMangHaiChieu(arr, n, m);
        xuatMangHaiChieu(arr, n, m);

        int[][] tam = new int[n][m];
        taoMangHaiChieu(arr, n, m, tam);
        System.out.println("nhap cot x: ");
        int x = Integer.parseInt(input.readLine());
        sapXepCotXTangDan(tam, n, m, x);
        xuatMangHaiChieu(tam, n, m);

        int tong1 = tongDongChanCotLe(arr, n, m);
        System.out.println("Tong phan tu dong chan cot le: " + tong1);

        timSoChinhPhuong(arr, n, m);

    }

    public static void nhapMangHaiChieu(int[][] arr, int n, int m) throws UnsupportedEncodingException, IOException {
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in, "UTF-8"));

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                System.out.println("phan tu dong " + i + " cot " + j);
                arr[i][j] = Integer.parseInt(input.readLine());
            }
        }
    }

    public static void xuatMangHaiChieu(int[][] arr, int n, int m) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print(arr[i][j] + "  ");
            }
            System.out.println();
        }
    }

    public static void taoMangHaiChieu(int[][] mangGoc, int n, int m, int[][] mangChep) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                mangChep[i][j] = mangGoc[i][j];
            }
        }
    }

    public static void sapXepCotXTangDan(int[][] arr, int n, int m, int x) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (j == x) {

                    for (int k = i + 1; k < n; k++) {
                        if (arr[i][j] > arr[k][j]) {
                            int tam = arr[i][j];
                            arr[i][j] = arr[k][j];
                            arr[k][j] = tam;
                        }
                    }
                }
            }
        }
    }

    public static int tongDongChanCotLe(int[][] arr, int n, int m) {
        int tong = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (i % 2 == 0 && j % 2 != 0) {
                    tong += arr[i][j];
                }
            }
        }
        return tong;
    }

    //public static tong
    public static void timSoChinhPhuong(int[][] arr, int n, int m) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                for (int k = 0; k < arr[i][j]; k++) {
                    if (k * k == arr[i][j]) {
                        System.out.println("So chinh phuong: " + arr[i][j] + " = " + k + " mu 2");
                        System.out.println("vi tri dong: " + i + " cot " + j);
                    }
                }
            }
        }
    }
}
