/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.Random;

/**
 *
 * @author hocvien
 */
public class Bai3Mang2Chieu {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws UnsupportedEncodingException, IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in, "UTF-8"));
        try {
            System.out.println("Nhap co dong n: ");
            int n = Integer.parseInt(input.readLine());

            System.out.println("Nhap so cot m: ");
            int m = Integer.parseInt(input.readLine());

            int[][] arr = new int[n][m];
            randomMangHaiChieu(arr, n, m);
            xuatMangHaiChieu(arr, n, m);

            int[][] tam = new int[n][m];
            taoMangHaiChieu(arr, n, m, tam);

            System.out.println("nhap cot x: ");
            int x = Integer.parseInt(input.readLine());

            sapXepCotXTangDan(tam, n, m, x);
            xuatMangHaiChieu(tam, n, m);

            int tongDongChan = tongPhanTuDongChan(arr, n, m);
            System.out.println("Tong phan tu dong chan mang ban dau: " + tongDongChan);

            int tongCotLe = tongPhanTuCotLe(arr, n, m);
            System.out.println("Tong phan tu cot le mang ban dau: " + tongCotLe);

            int[][] tam1 = new int[n][m];
            taoMangHaiChieu(arr, n, m, tam1);
            thay1ChoSoNguyenTo(tam1, n, m);
            xuatMangHaiChieu(tam, n, m);

            int tongDongDau = tongDongDauTien(arr, n, m);
            System.out.println("Tong cac phan tu dong dau tien mang ban dau: " + tongDongDau);

            int tongDongCuoi = tongDongCuoiCung(arr, n, m);
            System.out.println("Tong cac phan tu dong cuoi cung mang ban dau: " + tongDongCuoi);

            int tongCotDau = tongCotDauTien(arr, n, m);
            System.out.println("Tong cac phan tu cot dau tien mang ban dau: " + tongCotDau);

            int tongCotCuoi = tongCotCuoiCung(arr, n, m);
            System.out.println("Tong cac phan tu cot cuoi cung mang ban dau: " + tongCotCuoi);

            timSoChinhPhuong(arr, n, m);
        } catch (NumberFormatException e) {
            System.out.println("loi nhap sai du lieu");
        }
    }

    public static void randomMangHaiChieu(int[][] arr, int n, int m) throws UnsupportedEncodingException, IOException {
        Random random = new Random();
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                //System.out.println("phan tu dong " + i + " cot " + j);
                arr[i][j] = random.nextInt(100);
            }
        }
    }

    public static void xuatMangHaiChieu(int[][] arr, int n, int m) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print(arr[i][j] + "  ");
            }
            System.out.println();
        }
    }

    public static void taoMangHaiChieu(int[][] mangGoc, int n, int m, int[][] mangChep) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                mangChep[i][j] = mangGoc[i][j];
            }
        }
    }

    public static void sapXepCotXTangDan(int[][] arr, int n, int m, int x) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (j == x) {

                    for (int k = i + 1; k < n; k++) {
                        if (arr[i][j] > arr[k][j]) {
                            int tam = arr[i][j];
                            arr[i][j] = arr[k][j];
                            arr[k][j] = tam;
                        }
                    }
                }
            }
        }
    }

    public static int tongPhanTuDongChan(int[][] arr, int n, int m) {
        int tong = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (i % 2 == 0) {
                    tong += arr[i][j];
                }
            }
        }
        return tong;
    }

    public static int tongPhanTuCotLe(int[][] arr, int n, int m) {
        int tong = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (j % 2 != 0) {
                    tong += arr[i][j];
                }
            }
        }
        return tong;
    }

    public static boolean timSoNguyenTo(int n) {
        int dem = 1;

        for (int i = 2; i <= n; i++) {
            if (n % i == 0) {
                dem++;
            }
        }

        return dem == 2;
    }

    public static void thay1ChoSoNguyenTo(int[][] arr, int n, int m) {

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (timSoNguyenTo(arr[i][j])) {
                    arr[i][j] = -1;
                }
            }
        }
    }

    public static int tongDongDauTien(int[][] arr, int n, int m) {
        int tong = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i == 0) {
                    tong += arr[i][j];
                }
            }
        }
        return tong;
    }

    public static int tongDongCuoiCung(int[][] arr, int n, int m) {
        int tong = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i == n - 1) {
                    tong += arr[i][j];
                }
            }
        }
        return tong;
    }

    public static int tongCotDauTien(int[][] arr, int n, int m) {
        int tong = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (j == 0) {
                    tong += arr[i][j];
                }
            }
        }
        return tong;
    }

    public static int tongCotCuoiCung(int[][] arr, int n, int m) {
        int tong = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (j == n - 1) {
                    tong += arr[i][j];
                }
            }
        }
        return tong;
    }

    public static void timSoChinhPhuong(int[][] arr, int n, int m) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                for (int k = 0; k < arr[i][j]; k++) {
                    if (k * k == arr[i][j]) {
                        System.out.println("So chinh phuong: " + arr[i][j] + " = " + k + " mu 2");
                        System.out.println("vi tri dong: " + i + " cot " + j);
                    }
                }
            }
        }
    }
}
