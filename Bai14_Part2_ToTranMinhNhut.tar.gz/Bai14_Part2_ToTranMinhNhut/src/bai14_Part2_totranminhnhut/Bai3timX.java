/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai14_Part2_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai3timX {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap n: ");
        int n = Integer.parseInt(input.readLine());

        System.out.println("Nhap cac gia tri cho cac phan tu trong mang: ");
        int[] arr = new int[n];
        nhapMang(n, arr);

        System.out.println("Nhap x: ");
        int x = Integer.parseInt(input.readLine());

        System.out.println("Mang da nhap: ");
        xuatMang(n, arr);
        System.out.println();

        if (timX(x, arr) > (-1)) {
            System.out.println("x = " + x + " xuat hien trong mang");
        } else {
            System.out.println("x = " + x + " khong xuat hien trong mang");
        }

        System.out.println("Nhung so lon hon " + x);
        for (int i = 0; i < n; i++) {
            if (x < arr[i]) {
                System.out.println(arr[i]);
            }
        }
    }

    public static void nhapMang(int n, int[] a) throws IOException {
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        for (int i = 0; i < n; i++) {
            a[i] = Integer.parseInt(input.readLine());
        }
    }

    public static void xuatMang(int n, int[] a) {
        for (int i = 0; i < n; i++) {
            System.out.print(a[i] + " ");
        }
    }

    public static int timX(int x, int[] a) {
        int xuathien = -1;

        for (int i = 0; i < a.length; i++) {
            if (x == a[i]) {
                xuathien = i;
            }
        }

        return xuathien;
    }

}
