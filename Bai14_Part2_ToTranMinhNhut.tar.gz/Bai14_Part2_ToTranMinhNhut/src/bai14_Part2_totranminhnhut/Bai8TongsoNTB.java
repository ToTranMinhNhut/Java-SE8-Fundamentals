/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai14_Part2_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai8TongsoNTB {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap n: ");
        int n = Integer.parseInt(input.readLine());

        double E = tongSoNguyenTo(n);

        System.out.println("Ket qua E = " + E);
    }

    public static boolean kiemtraSoNguyenTo(int x) {
        int count = 1;

        for (int i = 2; i <= x; i++) {
            if ((x % i) == 0) {
                count++;
            }
        }
        
        return count == 2;
    }

    public static double tongSoNguyenTo(int n) {
        double E = 0;

        for (int i = 2; i <= n; i++) {
            
            if (kiemtraSoNguyenTo(i)) {
                E += i;
            }
        }

        return E;
    }

}
