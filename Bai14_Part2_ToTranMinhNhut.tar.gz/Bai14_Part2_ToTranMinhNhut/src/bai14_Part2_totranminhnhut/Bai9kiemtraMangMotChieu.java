/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai14_Part2_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai9kiemtraMangMotChieu {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap n: ");
        int n = Integer.parseInt(input.readLine());

        int[] arr = new int[n];

        nhapMang(n, arr);

        System.out.println("Mang vua nhap: ");
        xuatMang(n, arr);
        System.out.println();

        kiemtraMangTangDan(n, arr);

        kiemtraMangGiamDan(n, arr);

        timSoDauTienTanCungLa6(n, arr);
    }

    public static void nhapMang(int n, int[] arr) throws IOException {
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap cac phan tu cua mang: ");
        for (int i = 0; i < n; i++) {
            arr[i] = Integer.parseInt(input.readLine());
        }
    }

    public static void xuatMang(int n, int[] arr) {
        for (int i = 0; i < n; i++) {
            System.out.print(arr[i] + " ");
        }
    }

    public static void kiemtraMangTangDan(int n, int[] arr) {

        int compare1 = 0;

        for (int i = 0; i < n - 1; i++) {
            int j = i + 1;
            if (arr[i] < arr[j]) {
                compare1++;
            }
        }

        if (compare1 != n - 1) {
            System.out.println("Mang vua nhap khong tang dan");
        } else {
            System.out.println("Mang vua nhap tang dang ");
        }
    }

    public static void kiemtraMangGiamDan(int n, int[] arr) {
        int compare2 = 0;

        for (int i = 0; i < n - 1; i++) {
            int j = i + 1;
            if (arr[i] > arr[j]) {
                compare2++;
            }
        }

        if (compare2 != n - 1) {
            System.out.println("Mang vua nhap khong giam dan");
        } else {
            System.out.println("Mang vua nhap giam dang ");
        }
    }

    public static void timSoDauTienTanCungLa6(int n, int[] arr) {
        
        for (int i = 0; i < n; i++) {
            if ((arr[i] % 10) == 6) {
                System.out.println("so can tim la " + arr[i] + " o vi tri so " + i);
                break;
            }
        }
    }

}
