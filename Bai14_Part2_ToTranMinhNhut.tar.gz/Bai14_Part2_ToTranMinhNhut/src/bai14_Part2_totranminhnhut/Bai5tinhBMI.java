/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai14_Part2_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai5tinhBMI {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap chieu cao (m): ");
        double chieuCao = Double.parseDouble(input.readLine());

        System.out.println("Nhap can nang (kg): ");
        double canNang = Double.parseDouble(input.readLine());

        double BMI = tinhBMI(canNang, chieuCao);
        danhGiaBMI(BMI);

    }

    public static double tinhBMI(double canNang, double chieuCao) {

        double BMI = canNang / (chieuCao * chieuCao);
        return BMI;
    }

    public static void danhGiaBMI(double BMI) {

        if (BMI < 18.5) {
            System.out.println("BMI = " + BMI + " Ket luan : Ban Gay");
        } else if (BMI < 24.99) {
            System.out.println("BMI = " + BMI + " Ket luan : Ban binh thuong");
        } else {
            System.out.println("BMI = " + BMI + " Ket luan : Ban thua can");
        }
    }

}
