/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai14_Part2_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai2tinhA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap n: ");
        int n = Integer.parseInt(input.readLine());

        System.out.println("Nhap x: ");
        float x = Float.parseFloat(input.readLine());

        double A1 = 0;

        if (n == 0) {
            A1 = 2;
        } else {
            double Atam1 = 1;
            double Atam2 = 1;

            for (int i = 1; i <= n; i++) {
                Atam1 *= (x * x + x + 1);
                Atam2 *= (x * x - x + 1);
                A1 = Atam1 + Atam2;
            }
        }

        double A2 = tinhA(n, x);
        
        System.out.println("Cach viet thuong: A1 = " + A1);
        System.out.println("Canh viet ham: A2 = " + A2);
    }

    public static double tinhA(int n, double x) {
        double A = 0;

        if (n == 0) {
            A = 2;
        } else {
            double A1 = 1;
            double A2 = 1;

            for (int i = 1; i <= n; i++) {
                A1 *= (x * x + x + 1);
                A2 *= (x * x - x + 1);
                A = A1 + A2;
            }
        }

        return A;
    }

}
