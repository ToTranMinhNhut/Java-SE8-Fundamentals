/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai14_Part2_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

/**
 *
 * @author hocvien
 */
public class Bai7xulyMangNgauNhien {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap n: ");
        int n = Integer.parseInt(input.readLine());

        int[] arr = new int[n];
        phatsinhMangNgauNhien(n, arr);
        
        int SumArr = tongMangNgauNhien(n, arr);

        System.out.println("\nTong : " + SumArr);
    }

    public static void phatsinhMangNgauNhien(int n, int[] arr) {
        Random random = new Random();

        for (int i = 0; i < n; i++) {
            arr[i] = random.nextInt(n);
        }
    }

    public static int tongMangNgauNhien(int n, int[] arr) {
        int SumArr = 0;
        
        for (int value : arr) {
            System.out.print(value + " ");
            SumArr += value;
        }

        return SumArr;
    }

}
