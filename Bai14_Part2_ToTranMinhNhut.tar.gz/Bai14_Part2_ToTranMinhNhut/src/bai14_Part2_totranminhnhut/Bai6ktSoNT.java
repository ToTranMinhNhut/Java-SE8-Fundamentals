/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai14_Part2_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai6ktSoNT {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap x: ");
        int x = Integer.parseInt(input.readLine());

        if (ktSoNguyenTo(x)) {
            System.out.println(x + " la so Nguyen to!");
        } else {
            System.out.println(x + " khong phai la so nguyen to");
        }

    }

    public static boolean ktSoNguyenTo(int x) {
        int count = 1;

        for (int i = 2; i <= x; i++) {
            if ((x % i) == 0) {
                count++;
            }
        }

        return count == 2;
    }

}
