/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai14_Part2_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai8inBangcuuchuong {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap so bat dau: ");
        int sobatdau = Integer.parseInt(input.readLine());

        System.out.println("Nhap so ket thuc: ");
        int soketthuc = Integer.parseInt(input.readLine());
        
        inBangCuuChuong(sobatdau, soketthuc);

    }

    public static void inBangCuuChuong(int soBatDau, int soKetThuc) {

        for (int i = 1; i <= 9; i++) {

            for (int j = soBatDau; j <= soKetThuc; j++) {
                System.out.print(j + " x " + i + " = " + (i * j) + "\t");
            }
            System.out.print("\n");
        }
    }

}
