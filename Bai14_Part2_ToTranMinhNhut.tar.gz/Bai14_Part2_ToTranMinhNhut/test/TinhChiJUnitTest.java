/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import bai14_Part2_totranminhnhut.Bai4tinhNamAmLich;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author minhnhutvaio
 */
public class TinhChiJUnitTest {

    public TinhChiJUnitTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void ktTinhChi1() {
        String ex = "Dậu";
        String ac = Bai4tinhNamAmLich.tinhChi(1993);
        assertEquals(ex, ac);
    }

    @Test
    public void ktTinhChi2() {
        String ex = "Thân";
        String ac = Bai4tinhNamAmLich.tinhChi(0);
        assertEquals(ex, ac);
    }

    @Test
    public void ktTinhChi3() {
        String ex = "Thân";
        String ac = Bai4tinhNamAmLich.tinhChi(1000000);
        assertEquals(ex, ac);
    }

    @Test
    public void ktTinhChi4() {
        String ex = "";
        String ac = Bai4tinhNamAmLich.tinhChi(-10);
        assertEquals(ex, ac);
    }

    @Test
    public void ktTinhChi5() {
        String ex = "Mùi";
        String ac = Bai4tinhNamAmLich.tinhChi(9999);
        assertEquals(ex, ac);
    }

    @Test
    public void ktTinhChi6() {
        String ex = "Mùi";
        String ac = Bai4tinhNamAmLich.tinhChi(2002);
        assertEquals(ex, ac);
    }

    @Test
    public void ktTinhChi7() {
        String ex = "Tuất";
        String ac = Bai4tinhNamAmLich.tinhChi(2005);
        assertEquals(ex, ac);
    }

    @Test
    public void ktTinhChi8() {
        String ex = "Tý";
        String ac = Bai4tinhNamAmLich.tinhChi(1966);
        assertEquals(ex, ac);
    }

    @Test
    public void ktTinhCh9() {
        String ex = "Mùi";
        String ac = Bai4tinhNamAmLich.tinhChi(1980);
        assertEquals(ex, ac);
    }

    @Test
    public void ktTinhChi10() {
        String ex = "Tý";
        String ac = Bai4tinhNamAmLich.tinhChi(1954);
        assertEquals(ex, ac);
    }
}
