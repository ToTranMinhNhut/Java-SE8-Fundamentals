/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import bai14_Part2_totranminhnhut.Bai6doiTPsangNP;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author minhnhutvaio
 */
public class DoiTPSangNPJUnitTest {
    
    public DoiTPSangNPJUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void ktDoiTPSangNP1() {
        String ex = "0";
        String ac = Bai6doiTPsangNP.doiThanPhanSangNhiPhan(0);
        assertEquals(ex, ac);
    }
    
    @Test
    public void ktDoiTPSangNP2() {
        String ex = "1";
        String ac = Bai6doiTPsangNP.doiThanPhanSangNhiPhan(1);
        assertEquals(ex, ac);
    }
    
    @Test
    public void ktDoiTPSangNP3() {
        String ex = "1100100";
        String ac = Bai6doiTPsangNP.doiThanPhanSangNhiPhan(100);
        assertEquals(ex, ac);
    }
    
    @Test
    public void ktDoiTPSangNP4() {
        String ex = "101110110110011";
        String ac = Bai6doiTPsangNP.doiThanPhanSangNhiPhan(23987);
        assertEquals(ex, ac);
    }
    
    @Test
    public void ktDoiTPSangNP5() {
        String ex = "111011100110101100100111111111";
        String ac = Bai6doiTPsangNP.doiThanPhanSangNhiPhan(999999999);
        assertEquals(ex, ac);
    }
    
    @Test
    public void ktDoiTPSangNP6() {
        String ex = "110011";
        String ac = Bai6doiTPsangNP.doiThanPhanSangNhiPhan(30);
        assertEquals(ex, ac);
    }
    
    
    @Test
    public void ktDoiTPSangNP7() {
        String ex = "10100";
        String ac = Bai6doiTPsangNP.doiThanPhanSangNhiPhan(21);
        assertEquals(ex, ac);
    }
    
    @Test
    public void ktDoiTPSangNP8() {
        String ex = "101100";
        String ac = Bai6doiTPsangNP.doiThanPhanSangNhiPhan(89);
        assertEquals(ex, ac);
    }
    
    @Test
    public void ktDoiTPSangNP9() {
        String ex = "11001001";
        String ac = Bai6doiTPsangNP.doiThanPhanSangNhiPhan(200);
        assertEquals(ex, ac);
    }
    
    @Test
    public void ktDoiTPSangNP10() {
        String ex = "0";
        String ac = Bai6doiTPsangNP.doiThanPhanSangNhiPhan((int)1.1);
        assertEquals(ex, ac);
    }
}
