/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import bai14_Part2_totranminhnhut.Bai1tinhS;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class TinhSJUnitTest {
    
    public TinhSJUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void ktTinhS1() {
        double ex = 456976;
        double ac = Bai1tinhS.tinhS(4, 5);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTinhS2() {
        double ex = 1;
        double ac = Bai1tinhS.tinhS(0, 0);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTinhS3() {
        double ex = 456976;
        double ac = Bai1tinhS.tinhS(4, -5);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTinhS4() {
        double ex = 1;
        double ac = Bai1tinhS.tinhS(10000, 0);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTinhS5() {
        double ex = 1;
        double ac = Bai1tinhS.tinhS(0, 1000000);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTinhS6() {
        double ex = 1;
        double ac = Bai1tinhS.tinhS(1, -1);
        assertEquals(ex, ac, 0);
        
    }
    
    @Test
    public void ktTinhS7() {
        double ex = 1;
        double ac = Bai1tinhS.tinhS(-2, -1);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTinhS8() {
        double ex = 1;
        double ac = Bai1tinhS.tinhS(-2, -3);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTinhS9() {
        double ex = 1;
        double ac = Bai1tinhS.tinhS(3, -4);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTinhS10() {
        double ex = 1;
        double ac = Bai1tinhS.tinhS((int)4.5, 3);
        assertEquals(ex, ac, 0);
    }
}
