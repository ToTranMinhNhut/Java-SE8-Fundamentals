/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import bai14_Part2_totranminhnhut.Bai3timX;
import bai14_Part2_totranminhnhut.Bai4tinhNamAmLich;
import bai14_Part2_totranminhnhut.Bai5tinhBMI;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author minhnhutvaio
 */
public class TinhBMIJUnitTest {
    
    public TinhBMIJUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void ktTinhBMI1() {
        double ex = 18.73;
        double ac = Bai5tinhBMI.tinhBMI(45, 1.55);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void ktTinhBMI2() {
        double ex = 21.785;
        double ac = Bai5tinhBMI.tinhBMI(3.5, 0.4);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void ktTinhBMI3() {
        double ex = 19.2;
        double ac = Bai5tinhBMI.tinhBMI(120, 2.5);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void ktTinhBMI4() {
        double ex = 13.333333;
        double ac = Bai5tinhBMI.tinhBMI(30, 1.5);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void ktTinhBMI5() {
        double ex = 11.83432;
        double ac = Bai5tinhBMI.tinhBMI(30, 1.3);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void ktTinhBMI6() {
        double ex = 21.2;
        double ac = Bai5tinhBMI.tinhBMI(65, 1.75);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void ktTinhBMI7() {
        double ex = 20.77;
        double ac = Bai5tinhBMI.tinhBMI(60, 1.7);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void ktTinhBMI8() {
        double ex = -18.73;
        double ac = Bai5tinhBMI.tinhBMI(45, -1.55);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void ktTinhBMI9() {
        double ex = -18.73;
        double ac = Bai5tinhBMI.tinhBMI(-45, 1.55);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void ktTinhBMI10() {
        double ex = 18.73;
        double ac = Bai5tinhBMI.tinhBMI(-45, -1.55);
        assertEquals(ex, ac, 0.01);
    }
}
