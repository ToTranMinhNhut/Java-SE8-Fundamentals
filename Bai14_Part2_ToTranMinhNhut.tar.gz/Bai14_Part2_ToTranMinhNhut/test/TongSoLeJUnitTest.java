/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import bai14_Part2_totranminhnhut.Bai6TinhGTBT;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author minhnhutvaio
 */
public class TongSoLeJUnitTest {
    
    public TongSoLeJUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void ktTongSoLe1() {
        double ex = 0;
        double ac = Bai6TinhGTBT.tongSoLe(0);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTongSoLe2() {
        double ex = 25;
        double ac = Bai6TinhGTBT.tongSoLe(10);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTongSoLe3() {
        double ex = 250000;
        double ac = Bai6TinhGTBT.tongSoLe(1000);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTongSoLe4() {
        double ex = 1936;
        double ac = Bai6TinhGTBT.tongSoLe(88);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTongSoLe5() {
        double ex = 73984;
        double ac = Bai6TinhGTBT.tongSoLe(534);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTongSoLe6() {
        double ex = 0;
        double ac = Bai6TinhGTBT.tongSoLe(-1);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTongSoLe7() {
        double ex = 0;
        double ac = Bai6TinhGTBT.tongSoLe(-10);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTongSoLe8() {
        double ex = 0;
        double ac = Bai6TinhGTBT.tongSoLe(-133);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTongSoLe9() {
        double ex = 0;
        double ac = Bai6TinhGTBT.tongSoLe(-4);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTongSoLe10() {
        double ex = 0;
        double ac = Bai6TinhGTBT.tongSoLe((int)1.1);
        assertEquals(ex, ac, 0);
    }
}
