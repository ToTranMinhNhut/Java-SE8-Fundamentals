/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import bai14_Part2_totranminhnhut.Bai8TongsoNTB;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class TongSoNTJUnitTest {

    public TongSoNTJUnitTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void ktTongSoNT1() {
        double ex = 10;
        double ac = Bai8TongsoNTB.tongSoNguyenTo(5);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTongSoNT2() {
        double ex = 17;
        double ac = Bai8TongsoNTB.tongSoNguyenTo(10);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTongSoNT3() {
        double ex = 41;
        double ac = Bai8TongsoNTB.tongSoNguyenTo(13);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTongSoNT4() {
        double ex = 100;
        double ac = Bai8TongsoNTB.tongSoNguyenTo(25);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTongSoNT5() {
        double ex = 129;
        double ac = Bai8TongsoNTB.tongSoNguyenTo(30);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTongSoNT6() {
        double ex = 198;
        double ac = Bai8TongsoNTB.tongSoNguyenTo(40);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTongSoNT7() {
        double ex = 98;
        double ac = Bai8TongsoNTB.tongSoNguyenTo(27);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTongSoNT8() {
        double ex = 3;
        double ac = Bai8TongsoNTB.tongSoNguyenTo(3);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTongSoNT9() {
        double ex = 38;
        double ac = Bai8TongsoNTB.tongSoNguyenTo(15);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTongSoNT10() {
        double ex = 56;
        double ac = Bai8TongsoNTB.tongSoNguyenTo(18);
        assertEquals(ex, ac, 0);
    }
}
