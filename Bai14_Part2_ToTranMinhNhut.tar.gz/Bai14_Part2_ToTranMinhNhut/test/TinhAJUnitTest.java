/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import bai14_Part2_totranminhnhut.Bai2tinhA;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author minhnhutvaio
 */
public class TinhAJUnitTest {

    public TinhAJUnitTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void testTinhA1() {
        double ex = 370;
        double ac = Bai2tinhA.tinhA(3, 2);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void testTinhA2() {
        double ex = 2;
        double ac = Bai2tinhA.tinhA(0, 0);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void testTinhA3() {
        double ex = 370;
        double ac = Bai2tinhA.tinhA(3, -2);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void testTinhA4() {
        double ex = 2;
        double ac = Bai2tinhA.tinhA(-2,-1);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void testTinhA5() {
        double ex = 2;
        double ac = Bai2tinhA.tinhA(0, 100000);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void testTinhA6() {
        double ex = 2;
        double ac = Bai2tinhA.tinhA(1, -1);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void testTinhA7() {
        double ex = 2;
        double ac = Bai2tinhA.tinhA(-2, -1);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void testTinhA8() {
        double ex = 2;
        double ac = Bai2tinhA.tinhA(-2, -3);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void testTinhA9() {
        double ex = 2;
        double ac = Bai2tinhA.tinhA(3, -4);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void testTinhA10() {
        double ex = 4.5;
        double ac = Bai2tinhA.tinhA((int)4.5, 3);
        assertEquals(ex, ac, 0);
    }

}
