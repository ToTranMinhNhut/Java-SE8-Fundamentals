/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import bai14_Part2_totranminhnhut.Bai8doiNPsangTP;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author minhnhutvaio
 */
public class DoiNPSangTPJUnitTest {

    public DoiNPSangTPJUnitTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void ktDoiNPSangTP1() {
        double ex = 15;
        String np = "1111";
        double ac = Bai8doiNPsangTP.doiSoNhiPhanSangSoThapPhan(np);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktDoiNPSangTP2() {
        double ex = 42;
        String np = "101010";
        double ac = Bai8doiNPsangTP.doiSoNhiPhanSangSoThapPhan(np);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktDoiNPSangTP3() {
        double ex = 12;
        String np = "1100";
        double ac = Bai8doiNPsangTP.doiSoNhiPhanSangSoThapPhan(np);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktDoiNPSangTP4() {
        double ex = 4;
        String np = "100";
        double ac = Bai8doiNPsangTP.doiSoNhiPhanSangSoThapPhan(np);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktDoiNPSangTP5() {
        double ex = 2;
        String np = "10";
        double ac = Bai8doiNPsangTP.doiSoNhiPhanSangSoThapPhan(np);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktDoiNPSangTP6() {
        double ex = 23;
        String np = "11000";
        double ac = Bai8doiNPsangTP.doiSoNhiPhanSangSoThapPhan(np);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktDoiNPSangTP7() {
        double ex = 8;
        String np = "111";
        double ac = Bai8doiNPsangTP.doiSoNhiPhanSangSoThapPhan(np);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktDoiNPSangTP8() {
        double ex = 55;
        String np = "111001";
        double ac = Bai8doiNPsangTP.doiSoNhiPhanSangSoThapPhan(np);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktDoiNPSangTP9() {
        double ex = 8;
        String np = "1001";
        double ac = Bai8doiNPsangTP.doiSoNhiPhanSangSoThapPhan(np);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktDoiNPSangTP10() {
        double ex = 12;
        String np = "1101";
        double ac = Bai8doiNPsangTP.doiSoNhiPhanSangSoThapPhan(np);
        assertEquals(ex, ac, 0);
    }
}
