/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import bai14_Part2_totranminhnhut.Bai6TinhGTBT;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author minhnhutvaio
 */
public class TichDaySoChiaHetCho3JUnitTest {
    
    public TichDaySoChiaHetCho3JUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    
    @Test
    public void ktTichDaySoChiaHetCho3_1() {
        double ex = 0;
        double ac = Bai6TinhGTBT.tichSochiahetcho3(0);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void ktTichDaysoChiaHetCho3_2() {
        double ex = 0;
        double ac = Bai6TinhGTBT.tichSochiahetcho3(1);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void ktTichDaysoChiaHetCho3_3() {
        double ex = 3;
        double ac = Bai6TinhGTBT.tichSochiahetcho3(4);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void ktTichDaysoChiaHetCho3_4() {
        double ex = 162;
        double ac = Bai6TinhGTBT.tichSochiahetcho3(10);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void ktTichDaysoChiaHetCho3_5() {
        double ex = 8.435010925527457E307;
        double ac = Bai6TinhGTBT.tichSochiahetcho3(420);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void ktTichDaysoChiaHetCho3_6() {
        double ex = 1;
        double ac = Bai6TinhGTBT.tongSoLe(-1);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void ktTichDayso7() {
        double ex = 1;
        double ac = Bai6TinhGTBT.tongSoLe(-10);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void ktTichDayso8() {
        double ex = 1;
        double ac = Bai6TinhGTBT.tongSoLe(-7);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void ktTichDayso9() {
        double ex = 1;
        double ac = Bai6TinhGTBT.tongSoLe(-4);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void ktTichDayso10() {
        double ex = 1;
        double ac = Bai6TinhGTBT.tongSoLe((int) 1.1);
        assertEquals(ex, ac, 0);
    }
}
