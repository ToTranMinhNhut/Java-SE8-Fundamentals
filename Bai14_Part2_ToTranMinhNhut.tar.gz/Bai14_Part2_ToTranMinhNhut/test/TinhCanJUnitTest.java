/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import bai14_Part2_totranminhnhut.Bai4tinhNamAmLich;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author minhnhutvaio
 */
public class TinhCanJUnitTest {

    public TinhCanJUnitTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void ktTinhCan1() {
        String ex = "Qúy";
        String ac = Bai4tinhNamAmLich.tinhCan(1993);
        assertEquals(ex, ac);
    }
    
    @Test
    public void ktTinhCan2() {
        String ex = "Canh";
        String ac = Bai4tinhNamAmLich.tinhCan(0);
        assertEquals(ex, ac);
    }
    
    @Test
    public void ktTinhCan3() {
        String ex = "Canh";
        String ac = Bai4tinhNamAmLich.tinhCan(1000000);
        assertEquals(ex, ac);
    }
    
    @Test
    public void ktTinhCan4() {
        String ex = " ";
        String ac = Bai4tinhNamAmLich.tinhCan(-10);
        assertEquals(ex, ac);
    }
    
    @Test
    public void ktTinhCan5() {
        String ex = "Kỳ";
        String ac = Bai4tinhNamAmLich.tinhCan(9999);
        assertEquals(ex, ac);
    }
    
    @Test
    public void ktTinhCan6() {
        String ex = "Qúy";
        String ac = Bai4tinhNamAmLich.tinhCan(2002);
        assertEquals(ex, ac);
    }
    
    @Test
    public void ktTinhCan7() {
        String ex = "Bình";
        String ac = Bai4tinhNamAmLich.tinhCan(2005);
        assertEquals(ex, ac);
    }
    
    @Test
    public void ktTinhCan8() {
        String ex = "Ất";
        String ac = Bai4tinhNamAmLich.tinhCan(1966);
        assertEquals(ex, ac);
    }
    
    @Test
    public void ktTinhCan9() {
        String ex = "Kỳ";
        String ac = Bai4tinhNamAmLich.tinhCan(1980);
        assertEquals(ex, ac);
    }
    
    @Test
    public void ktTinhCan10() {
        String ex = "Canh";
        String ac = Bai4tinhNamAmLich.tinhCan(1954);
        assertEquals(ex, ac);
    }
    
}
