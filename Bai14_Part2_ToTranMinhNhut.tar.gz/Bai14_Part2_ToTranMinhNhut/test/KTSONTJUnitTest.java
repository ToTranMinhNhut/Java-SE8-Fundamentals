/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import bai14_Part2_totranminhnhut.Bai6ktSoNT;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author minhnhutvaio
 */
public class KTSONTJUnitTest {
    
    public KTSONTJUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void ktSoNT1() {
        boolean ac = Bai6ktSoNT.ktSoNguyenTo(2);
        assertTrue(ac);
    }
    
    @Test
    public void ktSoNT2() {
        boolean ac = Bai6ktSoNT.ktSoNguyenTo(3);
        assertTrue(ac);
    }
    
    @Test
    public void ktSoNT3() {
        boolean ac = Bai6ktSoNT.ktSoNguyenTo(17);
        assertTrue(ac);
    }
    
    @Test
    public void ktSoNT4() {
        boolean ac = Bai6ktSoNT.ktSoNguyenTo(1111);
        assertTrue(ac);
    }
    
    @Test
    public void ktSoNT5() {
        boolean ac = Bai6ktSoNT.ktSoNguyenTo(9999991);
        assertTrue(ac);
    }
    
    @Test
    public void ktSoNT6() {
        boolean ac = Bai6ktSoNT.ktSoNguyenTo(4);
        assertTrue(ac);
    }
    
    @Test
    public void ktSoNT7() {
        boolean ac = Bai6ktSoNT.ktSoNguyenTo(-10);
        assertTrue(ac);
    }
    
    @Test
    public void ktSoNT8() {
        boolean ac = Bai6ktSoNT.ktSoNguyenTo(1);
        assertTrue(ac);
    }
    
    @Test
    public void ktSoNT9() {
        boolean ac = Bai6ktSoNT.ktSoNguyenTo(0);
        assertTrue(ac);
    }
    
    @Test
    public void ktSoNT10() {
        boolean ac = Bai6ktSoNT.ktSoNguyenTo((int)1.1);
        assertTrue(ac);
    }
}
