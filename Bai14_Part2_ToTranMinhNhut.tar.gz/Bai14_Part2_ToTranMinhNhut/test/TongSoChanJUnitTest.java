/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import bai14_Part2_totranminhnhut.Bai6TinhGTBT;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author minhnhutvaio
 */
public class TongSoChanJUnitTest {

    public TongSoChanJUnitTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    @Test
    public void ktTongSoChan1() {
        double ex = 0;
        double ac = Bai6TinhGTBT.tongSoChan(0);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void ktTongSoChan2() {
        double ex = 30;
        double ac = Bai6TinhGTBT.tongSoChan(10);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void ktTongSoLe3() {
        double ex = 250000;
        double ac = Bai6TinhGTBT.tongSoChan(1000);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void ktTongSoLe4() {
        double ex = 0;
        double ac = Bai6TinhGTBT.tongSoChan(1);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void ktTongSoLe5() {
        double ex = 71556;
        double ac = Bai6TinhGTBT.tongSoChan(534);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void ktTongSoLe6() {
        double ex = 0;
        double ac = Bai6TinhGTBT.tongSoLe(-1);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void ktTongSoLe7() {
        double ex = 0;
        double ac = Bai6TinhGTBT.tongSoLe(-10);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void ktTongSoLe8() {
        double ex = 0;
        double ac = Bai6TinhGTBT.tongSoLe(-133);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void ktTongSoLe9() {
        double ex = 0;
        double ac = Bai6TinhGTBT.tongSoLe(-4);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void ktTongSoLe10() {
        double ex = 0;
        double ac = Bai6TinhGTBT.tongSoLe((int) 1.1);
        assertEquals(ex, ac, 0);
    }
}
