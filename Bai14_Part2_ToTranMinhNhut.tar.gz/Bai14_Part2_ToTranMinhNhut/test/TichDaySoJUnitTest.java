/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import bai14_Part2_totranminhnhut.Bai6TinhGTBT;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author minhnhutvaio
 */
public class TichDaySoJUnitTest {

    public TichDaySoJUnitTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    @Test
    public void ktTichDaySo1() {
        double ex = 0;
        double ac = Bai6TinhGTBT.tichDaySo(0);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void ktTichDayso2() {
        double ex = 1;
        double ac = Bai6TinhGTBT.tichDaySo(1);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void ktTichDayso3() {
        double ex = 24;
        double ac = Bai6TinhGTBT.tichDaySo(4);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void ktTichDayso4() {
        double ex = 3628800;
        double ac = Bai6TinhGTBT.tichDaySo(10);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void ktTichDayso5() {
        double ex = 7.26E+306;
        double ac = Bai6TinhGTBT.tichDaySo(170);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void ktTichDayso6() {
        double ex = 1;
        double ac = Bai6TinhGTBT.tongSoLe(-1);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void ktTichDayso7() {
        double ex = 1;
        double ac = Bai6TinhGTBT.tongSoLe(-10);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void ktTichDayso8() {
        double ex = 1;
        double ac = Bai6TinhGTBT.tongSoLe(-7);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void ktTichDayso9() {
        double ex = 1;
        double ac = Bai6TinhGTBT.tongSoLe(-4);
        assertEquals(ex, ac, 0);
    }

    @Test
    public void ktTichDayso10() {
        double ex = 1;
        double ac = Bai6TinhGTBT.tongSoLe((int) 1.1);
        assertEquals(ex, ac, 0);
    }
}
