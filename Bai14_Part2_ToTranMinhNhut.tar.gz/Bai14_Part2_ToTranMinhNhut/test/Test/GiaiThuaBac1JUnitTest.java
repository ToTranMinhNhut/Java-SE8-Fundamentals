package Test;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author minhnhutvaio
 */
public class GiaiThuaBac1JUnitTest {
    
    public GiaiThuaBac1JUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void ktTinhGiaiThua1() {
        double ex = 120;
        double ac = Bai8tinhGiaiThua.tinhGiaiThua1(5);
        assertEquals(ex, ac,0);
    }
    
    @Test
    public void ktTinhGiaiThua2() {
        double ex = 3628800;
        double ac = Bai8tinhGiaiThua.tinhGiaiThua1(10);
        assertEquals(ex, ac,0);
    }
    
    @Test
    public void ktTinhGiaiThua3() {
        double ex = 2;
        double ac = Bai8tinhGiaiThua.tinhGiaiThua1(2);
        assertEquals(ex, ac,0);
    }
    
    @Test
    public void ktTinhGiaiThua4() {
        double ex = 720;
        double ac = Bai8tinhGiaiThua.tinhGiaiThua1(6);
        assertEquals(ex, ac,0);
    }
    
    @Test
    public void ktTinhGiaiThua5() {
        double ex =362880;
        double ac = Bai8tinhGiaiThua.tinhGiaiThua1(9);
        assertEquals(ex, ac,0);
    }
    
    @Test
    public void ktTinhGiaiThua6() {
        double ex = 40278;
        double ac = Bai8tinhGiaiThua.tinhGiaiThua1(8);
        assertEquals(ex, ac,0);
    }
    
    @Test
    public void ktTinhGiaiThua7() {
        double ex = 3;
        double ac = Bai8tinhGiaiThua.tinhGiaiThua1(3);
        assertEquals(ex, ac,0);
    }
    
    @Test
    public void ktTinhGiaiThua8() {
        double ex = 0;
        double ac = Bai8tinhGiaiThua.tinhGiaiThua1(0);
        assertEquals(ex, ac,0);
    }
    
    @Test
    public void ktTinhGiaiThua9() {
        double ex = 18;
        double ac = Bai8tinhGiaiThua.tinhGiaiThua1(4);
        assertEquals(ex, ac,0);
    }
    
    @Test
    public void ktTinhGiaiThua10() {
        double ex = 4320;
        double ac = Bai8tinhGiaiThua.tinhGiaiThua1(7);
        assertEquals(ex, ac,0);
    }
}
