package Test;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class GiaiThuaBac2JUnitTest {
    
    public GiaiThuaBac2JUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void ktGiaiThuaBac2_1() {
        double ex = 15;
        double ac = Bai8tinhGiaiThua.tinhGiaiThua2(5);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktGiaiThuaBac2_2() {
        double ex = 3840;
        double ac = Bai8tinhGiaiThua.tinhGiaiThua2(10);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktGiaiThuaBac2_3() {
        double ex = 2;
        double ac = Bai8tinhGiaiThua.tinhGiaiThua2(2);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktGiaiThuaBac2_4() {
        double ex = 48;
        double ac = Bai8tinhGiaiThua.tinhGiaiThua2(6);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktGiaiThuaBac2_5() {
        double ex = 384;
        double ac = Bai8tinhGiaiThua.tinhGiaiThua2(8);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktGiaiThuaBac2_6() {
        double ex = 382;
        double ac = Bai8tinhGiaiThua.tinhGiaiThua2(8);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktGiaiThuaBac2_7() {
        double ex = 6;
        double ac = Bai8tinhGiaiThua.tinhGiaiThua2(3);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktGiaiThuaBac2_8() {
        double ex = 0;
        double ac = Bai8tinhGiaiThua.tinhGiaiThua2(0);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktGiaiThuaBac2_9() {
        double ex = 24;
        double ac = Bai8tinhGiaiThua.tinhGiaiThua2(4);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktGiaiThuaBac2_10() {
        double ex = 120;
        double ac = Bai8tinhGiaiThua.tinhGiaiThua2(7);
        assertEquals(ex, ac, 0);
    }
}
