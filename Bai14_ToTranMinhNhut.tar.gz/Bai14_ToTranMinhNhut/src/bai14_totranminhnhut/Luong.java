/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai14_totranminhnhut;

/**
 *
 * @author minhnhutvaio
 */
public class Luong {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }

    public double tinhLuong(double hesoLuong, double luongCoBan, double troCap, double thuong) {
        double luong = hesoLuong * luongCoBan + troCap + thuong;
        return luong;
    }

}
