/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai14_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author minhnhutvaio
 */
public class phuongTrinhBac2 {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("nhap a: ");
        double a = Double.parseDouble(input.readLine());

        System.out.println("nhap b: ");
        double b = Double.parseDouble(input.readLine());

        System.out.println("nhap c: ");
        double c = Double.parseDouble(input.readLine());

    }

    public double[] giaiPhuongTrinhBac2(double a, double b, double c) {
        double delta;
        double[] nghiem = new double[5];

        if (a == 0) {
            if (b == 0) {
                if (c == 0) {
                    nghiem[3] = -1;  // vo so nghiem
                } else {
                    nghiem[4] = 0; // nghiem vo ngiem
                }
            } else {
                nghiem[0] = (-c) / b; // nhat duy nhat
            }
        } else {
            delta = Math.pow(b, 2) - (4 * a * c);
            if (delta < 0) {
                nghiem[4] = 0;
            } else if (delta == 0) {
                nghiem[0] = -b / (2 * a);
            } else if (delta > 0) {
                nghiem[1] = (-b + Math.sqrt(delta)) / (2 * a);
                nghiem[2] = (-b - Math.sqrt(delta)) / (2 * a);
            }
        }
        return nghiem;
    }

}
