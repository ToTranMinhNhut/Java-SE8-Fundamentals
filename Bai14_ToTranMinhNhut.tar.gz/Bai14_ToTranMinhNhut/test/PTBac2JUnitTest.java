/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import bai14_totranminhnhut.phuongTrinhBac2;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author minhnhutvaio
 */
public class PTBac2JUnitTest {

    phuongTrinhBac2 pt = new phuongTrinhBac2();

    public PTBac2JUnitTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void ktGiaiPhuongTrinhBac2_1() {
        double ex = -1;
        double[] ac = pt.giaiPhuongTrinhBac2(0, 0, 0);
        assertEquals(ex, ac[3], 0);
    }

    @Test
    public void ktGiaiPhuongTrinhBac2_2() {
        double ex = 2;
        double[] ac = pt.giaiPhuongTrinhBac2(0, -2, 4);
        assertEquals(ex, ac[0], 0);
    }

    @Test
    public void ktGiaiPhuongTrinhBac2_3() {
        double ex = 0;
        double[] ac = pt.giaiPhuongTrinhBac2(0, 0, 4);
        assertEquals(ex, ac[3], 0);
    }

    @Test
    public void ktGiaiPhuongTrinhBac2_4() {
        double ex1 = 0, ex2 = -4;
        double[] ac = pt.giaiPhuongTrinhBac2(1, 4, 0);
        if (ac[1] == ex1 && ac[2] == ex2) {
            assertTrue(true);
        } else {
            assertTrue(false);
        }
    }

    @Test
    public void ktGiaiPhuongTrinhBac2_5() {
        double ex = 1;
        double[] ac = pt.giaiPhuongTrinhBac2(1, -2, 1);
        assertEquals(ex, ac[0], 0);
    }

    @Test
    public void ktGiaiPhuongTrinhBac2_6() {
        double ex = 0;
        double[] ac = pt.giaiPhuongTrinhBac2(2, 2, 1);
        assertEquals(ex, ac[4], 0);
    }

    @Test
    public void ktGiaiPhuongTrinhBac2_7() {
        double ex1 = -0.3, ex2 = -0.82;
        double[] ac = pt.giaiPhuongTrinhBac2(4, 4.5, 1);
        if (ac[1] == ex1 && ac[2] == ex2) {
            assertTrue(true);
        } else {
            assertTrue(false);
        }

    }

    @Test
    public void ktGiaiPhuongTrinhBac2_8() {
        double ex1 = 2, ex = 0.25;
        double[] ac = pt.giaiPhuongTrinhBac2(1, -2.25, 0.5);
        if (ac[1] == 2 && ac[2] == 0.25) {
            assertTrue(true);
        } else {
            assertTrue(false);
        }
    }

    @Test
    public void ktGiaiPhuongTrinhBac2_9() {
        double ex1 = -0.033, ex2 = 1.766;
        double[] ac = pt.giaiPhuongTrinhBac2(555, 999, 33);
        if (ac[1] == ex1 && ac[2] == ex2) {
            assertTrue(true);
        } else {
            assertTrue(false);
        }
    }

    @Test
    public void ktGiaiPhuongTrinhBac2_10() {
        double ex = 0;
        double[] ac = pt.giaiPhuongTrinhBac2(8, 5, 3);
        assertEquals(ex, ac[4], 0);
    }

}
