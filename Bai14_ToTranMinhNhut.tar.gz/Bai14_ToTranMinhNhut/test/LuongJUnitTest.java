/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import bai14_totranminhnhut.Luong;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class LuongJUnitTest {

    Luong luong = new Luong();

    public LuongJUnitTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void tinhLuong1() {
        double ex = 3041000;
        double ac = luong.tinhLuong(2.34, 1150000, 100000, 250000);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void tinhLuong2() {
        double ex = 3800000;
        double ac = luong.tinhLuong(3, 1150000, 150000, 250000);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void tinhLuong3() {
        double ex = 4329500;
        double ac = luong.tinhLuong(3.33, 1150000, 200000, 300000);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void tinhLuong4() {
        double ex = 4800000;
        double ac = luong.tinhLuong(3.66, 1150000, 300000, 300000);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void tinhLuong5() {
        double ex = 5338500;
        double ac = luong.tinhLuong(3.99, 1150000, 400000, 350000);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void tinhLuong6() {
        double ex = 2800000;
        double ac = luong.tinhLuong(2.22, 1150000, 150000, 150000);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void tinhLuong7() {
        double ex = 2646000;
        double ac = luong.tinhLuong(2.04, 1150000, 150000, 150000);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void tinhLuong8() {
        double ex = 3500000;
        double ac = luong.tinhLuong(2.67, 1150000, 200000, 250000);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void tinhLuong9() {
        double ex = 5803000;
        double ac = luong.tinhLuong(4.22, 1150000, 500000, 450000);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void tinhLuong10() {
        double ex = 6000000;
        double ac = luong.tinhLuong(4.55, 1150000, 300000, 500000);
        assertEquals(ex, ac, 0);
    }
    
}