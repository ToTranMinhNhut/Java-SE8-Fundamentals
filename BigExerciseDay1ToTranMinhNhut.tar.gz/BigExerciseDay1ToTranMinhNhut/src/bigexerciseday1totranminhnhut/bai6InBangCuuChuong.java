/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday1totranminhnhut;

/**
 *
 * @author hocvien
 */
public class bai6InBangCuuChuong {

    final static int SOPHANTU = 9;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        int tich = 0;
        for (int i = 1; i <= SOPHANTU; i++) {
            System.out.print(i + " | ");

            for (int j = 1; j <= SOPHANTU; j++) {
                tich = i * j;
                System.out.print(tich + "\t");
            }
            System.out.println();
        }
    }

}
