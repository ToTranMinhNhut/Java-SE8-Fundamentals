/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday1totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

/**
 *
 * @author hocvien
 */
public class bai1TinhCuocMobileInternet {

    final static String M0 = "M0";
    final static String M10 = "M10", M25 = "M25", M50 = "M50", M120 = "M120";
    final static String MAX = "MAX", MAX100 = "MAX100", MAX200 = "MAX200", MAXS = "MAXS";

    final static double cuocPhiM0 = 0;
    final static double cuocPhiM10 = 10000, cuocPhiM25 = 25000, cuocPhiM50 = 50000, cuocPhiM120 = 120000;
    final static double cuocPhiMAX = 70000, cuocPhiMAX100 = 100000, cuocPhiMAX200 = 200000, cuocPhiMAXS = 50000;

    final static double mienPhiM10 = 50 * 1024;
    final static double mienPhiM25 = 150 * 1024;
    final static double mienPhiM50 = 500 * 1024;
    final static double mienPhiM120 = 1.5 * 1024 * 1024;
    final static double mienPhiMAX = 600 * 1024;
    final static double mienPhiMAX100 = 1.2 * 1024 * 1024;
    final static double mienPhiMAX200 = 3 * 1024 * 1024;
    final static double mienPhiMAXS = 2 * 1024 * 1024;

    /**
     * @param args the command line arguments
     * @throws java.io.UnsupportedEncodingException
     */
    public static void main(String[] args) throws UnsupportedEncodingException, IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in, "UTF-8"));
        String tenCuoc = "";
        double dungLuong = 0;
        
        try {

            System.out.println("Nhap ten goi cuoc: ");
            tenCuoc = input.readLine();
            System.out.println("Nhap dung luong da su dung (Kb): ");
            dungLuong = Double.parseDouble(input.readLine());

        } catch (NumberFormatException e) {
            System.out.println("Loi nhap sai du lieu!");
        }

        double tienCuoc = tinhCuoc(tenCuoc, dungLuong);
        System.out.println("Tien Cuoc: " + tienCuoc);
    }

    public static double tinhCuoc(String tenCuoc, double dungLuong) {
        double tienCuoc = 0;

        if (tenCuoc.equals(M0)) {
            tienCuoc = cuocPhiM0 + dungLuong * 1.5;
        } else if (tenCuoc.equals(M10)) {
            tienCuoc = tinhCuocGoi2(dungLuong, mienPhiM10, cuocPhiM10);
        } else if (tenCuoc.equals(M25)) {
            tienCuoc = tinhCuocGoi2(dungLuong, mienPhiM25, cuocPhiM25);
        } else if (tenCuoc.equals(M50)) {
            tienCuoc = tinhCuocGoi2(dungLuong, mienPhiM50, cuocPhiM50);
        } else if (tenCuoc.equals(M120)) {
            tienCuoc = tinhCuocGoi2(dungLuong, mienPhiM120, cuocPhiM120);
        } else if (tenCuoc.equals(MAX)) {
            tienCuoc = cuocPhiMAX;
        } else if (tenCuoc.equals(MAX100)) {
            tienCuoc = cuocPhiMAX100;
        } else if (tenCuoc.equals(MAX200)) {
            tienCuoc = cuocPhiMAX200;
        } else if (tenCuoc.equals(MAXS)) {
            tienCuoc = cuocPhiMAXS;
        }
        return tienCuoc;
    }

    public static double tinhCuocGoi2(double dungLuong, double gioiHan, double cuocPhi) {
        double tienCuoc = 0;
        if (dungLuong <= gioiHan) {
            tienCuoc = cuocPhi;
        } else {
            tienCuoc = cuocPhi + (dungLuong - gioiHan) * 0.5;
        }
        return tienCuoc;
    }

}
