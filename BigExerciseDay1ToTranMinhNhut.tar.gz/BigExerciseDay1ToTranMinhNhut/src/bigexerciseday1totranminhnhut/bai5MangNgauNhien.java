/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday1totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.Random;

/**
 *
 * @author hocvien
 */
public class bai5MangNgauNhien {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws UnsupportedEncodingException, IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in, "UTF-8"));

        System.out.println("Nhap n: ");
        int n = Integer.parseInt(input.readLine());
        int[] arr = new int[n];

        taoMangNgauNhien(arr, n);

        System.out.println("Mang vua tao: ");
        xuatMang(arr, n);
        System.out.println();

        String[][] maTranVuongChuoi = new String[n][n];
        taoMaTranChuoiVuong(maTranVuongChuoi, n, arr);
        System.out.println("Ma tran vua tao");
        xuatMaTranChuoi(maTranVuongChuoi, n);

    }

    public static void taoMangNgauNhien(int[] arr, int n) {
        Random random = new Random();

        for (int i = 0; i < n; i++) {
            arr[i] = random.nextInt(n - 1);
        }
    }

    public static void xuatMang(int[] arr, int n) {
        for (int i = 0; i < n; i++) {
            System.out.print(arr[i] + " ");
        }
    }

    public static void taoMaTranChuoiVuong(String[][] st, int n, int[] arr) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (j == arr[i]) {
                    st[i][j] = "Q";
                } else {
                    st[i][j] = "*";
                }
            }
        }
    }

    public static void xuatMaTranChuoi(String[][] st, int n) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(st[i][j] + "\t");
            }
            System.out.println();
        }
    }

}
