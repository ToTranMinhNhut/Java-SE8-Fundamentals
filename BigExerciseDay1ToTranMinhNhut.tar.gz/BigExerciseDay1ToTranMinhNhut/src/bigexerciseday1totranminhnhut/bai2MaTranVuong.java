/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday1totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

/**
 *
 * @author hocvien
 */
public class bai2MaTranVuong {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws UnsupportedEncodingException, IOException {
        // TODO code application logic here

        BufferedReader input = new BufferedReader(new InputStreamReader(System.in, "UTF-8"));
        try {
            System.out.println("nhap n: ");
            int n = Integer.parseInt(input.readLine());

            int[][] arr = new int[n][n];

            nhapMaTranVuong(arr, n);

            System.out.println("Ma tran vua nhap: ");
            xuatMaTran(arr, n);

            timPhanTuLonNhatTrenDong(arr, n);
            timPhanTuNhoNhatTrenDong(arr, n);

            System.out.println("Nhap x: ");
            int x = Integer.parseInt(input.readLine());
            thayDuongCheo(arr, n, x);

            int amLonNhat = timPhanTuAmLonNhat(arr, n);
            System.out.println("Phan tu am lon nhat: " + amLonNhat);

            int duongNhoNha = timPhanTuDuongNhoNhat(arr, n);
            System.out.println("Phan tu duong nho nhat: " + duongNhoNha);

            int dem = demPTDuongTrenTamGiacTren(arr, n);
            System.out.println("So phan tu duong tren tam giac tren: " + dem);

            int sochia2va3 = demSoAmChiaHetCho2Va3(arr, n);
            System.out.println("So phan tu chia het cho 2 va 3: " + sochia2va3);
            
        } catch (NumberFormatException e) {
            System.out.println("nhap sai du lieu");
        }
    }

    public static void nhapMaTranVuong(int[][] arr, int n) throws UnsupportedEncodingException, IOException {
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in, "UTF-8"));

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.println("Phan tu dong " + i + " cot " + j);
                arr[i][j] = Integer.parseInt(input.readLine());
            }
        }
    }

    public static void xuatMaTran(int[][] arr, int n) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(arr[i][j] + "  ");
            }
            System.out.println();
        }
    }

    public static void timPhanTuLonNhatTrenDong(int[][] arr, int n) {
        int lonNhat = arr[0][0];

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (arr[i][j] >= lonNhat) {
                    lonNhat = arr[i][j];
                }
            }
            System.out.println("lon nhat dong " + i + " la: " + lonNhat);
        }
    }

    public static void timPhanTuNhoNhatTrenDong(int[][] arr, int n) {
        int nhoNhat = arr[0][0];

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (arr[i][j] <= nhoNhat) {
                    nhoNhat = arr[i][j];
                }
            }
            System.out.println("lon nho nhat dong " + i + " la: " + nhoNhat);
        }
    }

    public static void thayDuongCheo(int[][] arr, int n, int x) {
        int[][] arrT = new int[n][n];

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                arrT[i][j] = arr[i][j];
            }
        }

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i == j) {
                    arrT[i][j] = x;
                }

                if (i == n - 1 - j) {
                    arrT[i][j] = x;
                }
            }
        }
        xuatMaTran(arrT, n);
    }

    public static int soPhanTuAmLonNhat(int[][] arr, int n, int x) {
        int lonNhat = x;

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (arr[i][j] < 0) {
                    if (arr[i][j] >= lonNhat) {
                        lonNhat = arr[i][j];
                    }
                }
            }
        }
        return lonNhat;
    }

    public static int timPhanTuAmLonNhat(int[][] arr, int n) {
        int amLonNhat = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (arr[i][j] < 0) {
                    amLonNhat = soPhanTuAmLonNhat(arr, n, arr[i][j]);
                }
            }
        }
        return amLonNhat;
    }

    public static int soPhanTuDuongNhoNhat(int[][] arr, int n, int x) {
        int nhoNhat = x;

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (arr[i][j] > 0) {
                    if (arr[i][j] <= nhoNhat) {
                        nhoNhat = arr[i][j];
                    }
                }
            }
        }
        return nhoNhat;
    }

    public static int timPhanTuDuongNhoNhat(int[][] arr, int n) {
        int duongNhoNhat = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (arr[i][j] > 0) {
                    duongNhoNhat = soPhanTuDuongNhoNhat(arr, n, arr[i][j]);
                }
            }
        }
        return duongNhoNhat;
    }

    public static int demPTDuongTrenTamGiacTren(int[][] arr, int n) {
        int dem = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i <= j) {
                    if (arr[i][j] > 0) {
                        dem++;
                    }
                }
            }
        }
        return dem;
    }

    public static int demSoAmChiaHetCho2Va3(int[][] arr, int n) {
        int dem = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (arr[i][j] < 0 && (arr[i][j] % 2 == 0) && (arr[i][j] % 3 == 0)) {
                    dem++;
                }
            }
        }
        return dem;
    }
}
