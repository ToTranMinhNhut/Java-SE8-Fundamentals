/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday1totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.Random;

/**
 *
 * @author hocvien
 */
public class bai8DiemSinhVien {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws UnsupportedEncodingException, IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in, "UTF-8"));

        System.out.println("Nhap so luong sinh vien: ");
        int n = Integer.parseInt(input.readLine());

        int[] diem = new int[n];
        taoMangDiem(diem, n);

        for (int i = 0; i < n; i++) {
            System.out.print(diem[i] + " ");
        }
        System.out.println();

        String thongKe[] = thongKeDiem(diem, n);
        xuat(thongKe);

    }

    public static void taoMangDiem(int[] diem, int n) {
        Random random = new Random();

        for (int i = 0; i < n; i++) {
            diem[i] = random.nextInt(100);
        }
    }

    public static String[] thongKeDiem(int[] diem, int n) {
        String[] thongKe = new String[10];
        
        for (int i = 0; i < 10; i++) {
            thongKe[i] = "";
        }

        for (int i = 0; i < n; i++) {
            if (diem[i] >= 0 && diem[i] <= 9) {
                thongKe[0] += "*";
            } else if (diem[i] <= 19) {
                thongKe[1] += "*";
            } else if (diem[i] <= 29) {
                thongKe[2] += "*";
            } else if (diem[i] <= 39) {
                thongKe[3] += "*";
            } else if (diem[i] <= 49) {
                thongKe[4] += "*";
            } else if (diem[i] <= 59) {
                thongKe[5] += "*";
            } else if (diem[i] <= 69) {
                thongKe[6] += "*";
            } else if (diem[i] <= 79) {
                thongKe[7] += "*";
            } else if (diem[i] <= 89) {
                thongKe[8] += "*";
            } else if (diem[i] <= 100) {
                thongKe[9] += "*";
            }
        }
        return thongKe;
    }

    public static void xuat(String[] diem) {
        int tam1 = 0, tam2 = 9;

        for (int i = 0; i < diem.length; i++) {
            System.out.print(tam1 + " - " + tam2);
            System.out.println(": " + diem[i]);
            tam1 += 10;
            tam2 += 10;
        }
    }
}
