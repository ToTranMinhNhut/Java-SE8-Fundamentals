/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday1totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai7SoThapPhanVaThapLucPhan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap: <1><Thap Phan sang Thap Luc Phan>---<2><Thap Luc Phan sang NhiPhan>");
        int chonLua = Integer.parseInt(input.readLine());

        if (chonLua == 1) {
            System.out.println("Nhap so can doi: ");
            int soThapPhan = Integer.parseInt(input.readLine());
            String soThapLucPhan = thapPhanSangThapLucPhan(soThapPhan);
            System.out.println("So: " + soThapLucPhan);
        } else if (chonLua == 2) {
            System.out.println("Nhap so can doi: ");
            String soThapPhan = input.readLine();
            int soThapLucPhan = thapLucPhanSangThapPhan(soThapPhan);
            System.out.println("So: " + soThapLucPhan);
        }
    }

    public static String thapPhanSangThapLucPhan(int n) {
        String chuyendoi = "123456789ABCDEF";
        String thapLucPhan = "";
        int heSo = 16;
        while (n > 0) {
            int tam = n % heSo;
            thapLucPhan = chuyendoi.charAt(tam - 1) + thapLucPhan;
            n /= heSo;
        }
        return thapLucPhan;
    }

    public static int thapLucPhanSangThapPhan(String n) {
        String chuyendoi = "123456789ABCDEF";
        n = n.toUpperCase();
        int thapPhan = 0;
        int heSo = 16;
        for (int i = 0; i < n.length(); i++) {
            char tam = n.charAt(i);
            int heSo10 = chuyendoi.indexOf(tam);
            thapPhan = heSo*thapPhan + heSo10; 
        }
        return thapPhan;
    }
}
