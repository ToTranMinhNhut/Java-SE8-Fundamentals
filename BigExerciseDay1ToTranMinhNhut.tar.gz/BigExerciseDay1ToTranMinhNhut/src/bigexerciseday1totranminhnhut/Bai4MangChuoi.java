/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday1totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;

/**
 *
 * @author hocvien
 */
public class Bai4MangChuoi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws UnsupportedEncodingException, IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in, "UTF-8"));

        System.out.println("Nhap n: ");
        int n = Integer.parseInt(input.readLine());

        String[] St = new String[n];
        nhapMangChuoi(St, n);

        xuatMangChuoi(St, n);
        int viTri = timChuoiDaiNhat(St, n);
        System.out.println("Chuoi dai nhat co vi tri: " + viTri + " noi dung: " + St[viTri]);

        System.out.println("Nhap chuoi can tim: ");
        String chuoiCanTim = input.readLine();
        int viTriChuoiCT = timChuoi(St, n, chuoiCanTim);

        if (viTriChuoiCT >= 0) {
            System.out.println("Phan tu giong voi chuoi co vi tri: " + viTriChuoiCT);
        } else {
            System.out.println("Chuoi khong co trong mang");
        }

        String[] st2 = taoMangChuoiMoi(St);
        System.out.println("Mang Chuoi vua tao: ");
        xuatMangChuoi(st2, n);
        
        // sap xep mang
        Arrays.sort(st2);
        System.out.println("Mang vua sap xep");
        xuatMangChuoi(st2, n);
    }

    public static void nhapMangChuoi(String[] st, int n) throws UnsupportedEncodingException, IOException {
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in, "UTF-8"));

        for (int i = 0; i < n; i++) {
            System.out.println("Phan tu thu: " + i);
            st[i] = input.readLine();
        }
    }

    public static void xuatMangChuoi(String[] st, int n) {
        for (int i = 0; i < n; i++) {
            System.out.println("Phan tu thu: " + i);
            System.out.println("Noi dung: " + st[i] + ". Chieu dai: " + st[i].length());
        }
    }

    public static int timChuoiDaiNhat(String[] st, int n) {
        int daiNhat = st[0].length();
        int viTri = 0;
        for (int i = 0; i < n; i++) {
            if (st[i].length() >= daiNhat) {
                daiNhat = st[i].length();
                viTri = i;
            }
        }
        return viTri;
    }

    public static int timChuoi(String[] st, int n, String s) {
        int viTri = -1;
        for (int i = 0; i < n; i++) {
            if (s.equals(st[i])) {
                viTri = i;
            }
        }
        return viTri;
    }

    public static String[] taoMangChuoiMoi(String[] chuoiGoc) {
        String[] chuoiSaoChep = new String[chuoiGoc.length];
        System.arraycopy(chuoiGoc, 0, chuoiSaoChep, 0, chuoiGoc.length);
        return chuoiSaoChep;
    }
    
}
