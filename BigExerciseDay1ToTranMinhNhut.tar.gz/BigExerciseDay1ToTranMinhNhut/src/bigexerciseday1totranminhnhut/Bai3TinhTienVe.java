/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday1totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

/**
 *
 * @author hocvien
 */
public class Bai3TinhTienVe {

    final static String A2T = "A2T", A2TL = "A2TL";
    final static String AnLT1 = "AnLT1", AnLT2 = "AnLT2";
    final static String AnT1 = "AnT1", AnT2 = "AnT2";
    final static String BnLT1 = "BNLT1", BnLT2 = "BNLT2", BnLT3 = "BNLT3";
    final static String BnT1 = "BnT1", BnT2 = "BnT2", BnT3 = "BnT3";
    final static String GP = "GP", NC = "NC", NCL = "NCL", NM = "NM", NML = "NML", NML4V = "NM4V";

    final static double GiaA2T = 129000, GiaA2TL = 128000;
    final static double GiaAnLT1 = 249000, GiaAnLT2 = 218000;
    final static double GiaAnT1 = 202000, GiaAnT2 = 172000;
    final static double GiaBnLT1 = 214000, GiaBnLT2 = 189000, GiaBnLT3 = 163000;
    final static double GiaBnT1 = 193000, GiaBnT2 = 168000, GiaBnT3 = 146000;
    final static double GiaGP = 79000, GiaNC = 99000, GiaNCL = 116000, GiaNM = 129000, GiaNML = 155000, GiaNML4V = 171000;

    final static int TREEM = 0, NGUOILON = 1, NGUOIGIA = 2;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws UnsupportedEncodingException, IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in, "UTF-8"));

        int soVeNguoiLon = 0, soVeTreEm = 0, soVeNguoiGia = 0;
        int phanKhucNL = 99, phanKhucTE = 99, phanKhucNG = 99;
        String loaiGheChoNL = "", loaiGheChoNG = "", loaiGheChoTE = "";

        int tam = 0;
        while (tam == 0) {
            System.out.println("<Nhap 2 de mua ve><Nhap 0 de dung thao tac>: ");
            int lap = Integer.parseInt(input.readLine());

            if (lap == 2) {

                System.out.println("Chon phan khuc---<0><Tre em>---<1><Nguoi lon>---<2><Nguoi gia>: ");
                int phanKhuc = Integer.parseInt(input.readLine());

                if (phanKhuc == NGUOILON) {
                    phanKhucNL = phanKhuc;

                    System.out.println("Nhap loai ghe: ");
                    System.out.println("<<A2T, A2TL, AnLT1, AnLT2, AnT1, AnT2, BNLT1, BNLT2, BNLT3, BnT1, BnT2, BnT3, GP, NC, NCL, NM, NML, NM4V>>");
                    loaiGheChoNL = input.readLine();

                    System.out.println("Nhap so ve:  ");
                    soVeNguoiLon = Integer.parseInt(input.readLine());

                } else if (phanKhuc == TREEM) {
                    phanKhucTE = phanKhuc;
                    System.out.println("Nhap loai ghe: ");
                    System.out.println("<<A2T, A2TL, AnLT1, AnLT2, AnT1, AnT2, BNLT1, BNLT2, BNLT3, BnT1, BnT2, BnT3, GP, NC, NCL, NM, NML, NM4V>>");
                    loaiGheChoTE = input.readLine();

                    System.out.println("Nhap so ve:  ");
                    soVeTreEm = Integer.parseInt(input.readLine());

                } else if (phanKhuc == NGUOIGIA) {
                    phanKhucNG = phanKhuc;
                    System.out.println("Nhap loai ghe: ");
                    System.out.println("<<A2T, A2TL, AnLT1, AnLT2, AnT1, AnT2, BNLT1, BNLT2, BNLT3, BnT1, BnT2, BnT3, GP, NC, NCL, NM, NML, NM4V>>");
                    loaiGheChoNG = input.readLine();

                    System.out.println("Nhap so ve:  ");
                    soVeNguoiGia = Integer.parseInt(input.readLine());
                }

            } else if (lap == 0) {
                tam++;
            }
        }

        int tongSoVe = soVeNguoiLon + soVeTreEm + soVeNguoiGia;
        double tienVeNL = 0, tienVeTE = 0, tienVeNG = 0;

        if (phanKhucNL == 1) {
            tienVeNL = tinhTienVeNguoiLon(loaiGheChoNL, tam);
        }

        if (phanKhucTE == 0) {
            tienVeTE = tinhTienVeTreEm(loaiGheChoNG, tam);
        }

        if (phanKhucNG == 2) {
            tienVeNG = tinhTienVeNguoiGia(loaiGheChoTE, tam);
        }

        double tongTien = tienVeNL + tienVeTE + tienVeNG;

        System.out.println("Tong so ve: " + tongSoVe + " ve");
        System.out.println("Ve nguoi lon: " + soVeNguoiLon + " ve. Thanh tien: " + tienVeNL + " vnd");
        System.out.println("Ve nguoi gia: " + soVeNguoiGia + " ve. Thanh tien: " + tienVeNG + "vnd");
        System.out.println("Ve nguoi tre em: " + soVeTreEm + " ve. Thanh tien: " + tienVeTE + "vnd");
        System.out.println("Tong so tien: " + tongTien + " vnd");

    }

    public static double tinhTienVeNguoiLon(String loaiGhe, int soVe) {
        double thanhTien = 0;

        switch (loaiGhe) {
            case A2T:
                thanhTien = soVe * GiaA2T;
                break;
            case A2TL:
                thanhTien = soVe * GiaA2TL;
                break;
            case AnLT1:
                thanhTien = soVe * GiaAnLT1;
                break;
            case AnLT2:
                thanhTien = soVe * GiaAnLT2;
                break;
            case AnT1:
                thanhTien = soVe * GiaAnT1;
                break;
            case AnT2:
                thanhTien = soVe * GiaAnT2;
                break;
            case BnLT1:
                thanhTien = soVe * GiaBnLT1;
                break;
            case BnLT2:
                thanhTien = soVe * GiaBnLT2;
                break;
            case BnLT3:
                thanhTien = soVe * GiaBnLT3;
                break;
            case BnT1:
                thanhTien = soVe * GiaBnT1;
                break;
            case BnT2:
                thanhTien = soVe * GiaBnT2;
                break;
            case BnT3:
                thanhTien = soVe * GiaBnT3;
                break;
            case GP:
                thanhTien = soVe * GiaGP;
                break;
            case NC:
                thanhTien = soVe * GiaNC;
                break;
            case NCL:
                thanhTien = soVe * GiaNCL;
                break;
            case NM:
                thanhTien = soVe * GiaNM;
                break;
            case NML:
                thanhTien = soVe * GiaNML;
                break;
            case NML4V:
                thanhTien = soVe * GiaNML4V;
                break;
            default:
                break;
        }
        return thanhTien;
    }

    public static double tinhTienVeTreEm(String loaiGhe, int soVe) {
        double thanhTien = 0;

        switch (loaiGhe) {
            case A2T:
                thanhTien = soVe * (GiaA2T * 50 / 100);
                break;
            case A2TL:
                thanhTien = soVe * (GiaA2TL * 50 / 100);
                break;
            case AnLT1:
                thanhTien = soVe * (GiaAnLT1 * 50 / 100);
                break;
            case AnLT2:
                thanhTien = soVe * (GiaAnLT2 * 50 / 100);
                break;
            case AnT1:
                thanhTien = soVe * (GiaAnT1 * 50 / 100);
                break;
            case AnT2:
                thanhTien = soVe * (GiaAnT2 * 50 / 100);
                break;
            case BnLT1:
                thanhTien = soVe * (GiaBnLT1 * 50 / 100);
                break;
            case BnLT2:
                thanhTien = soVe * (GiaBnLT2 * 50 / 100);
                break;
            case BnLT3:
                thanhTien = soVe * (GiaBnLT3 * 50 / 100);
                break;
            case BnT1:
                thanhTien = soVe * (GiaBnT1 * 50 / 100);
                break;
            case BnT2:
                thanhTien = soVe * (GiaBnT2 * 50 / 100);
                break;
            case BnT3:
                thanhTien = soVe * (GiaBnT3 * 50 / 100);
                break;
            case GP:
                thanhTien = soVe * (GiaGP * 50 / 100);
                break;
            case NC:
                thanhTien = soVe * (GiaNC * 50 / 100);
                break;
            case NCL:
                thanhTien = soVe * (GiaNCL * 50 / 100);
                break;
            case NM:
                thanhTien = soVe * (GiaNM * 50 / 100);
                break;
            case NML:
                thanhTien = soVe * (GiaNML * 50 / 100);
                break;
            case NML4V:
                thanhTien = soVe * (GiaNML4V * 50 / 100);
                break;
            default:
                break;
        }
        return thanhTien;
    }

    public static double tinhTienVeNguoiGia(String loaiGhe, int soVe) {
        double thanhTien = 0;

        switch (loaiGhe) {
            case A2T:
                thanhTien = soVe * (GiaA2T * 75 / 100);
                break;
            case A2TL:
                thanhTien = soVe * (GiaA2TL * 75 / 100);
                break;
            case AnLT1:
                thanhTien = soVe * (GiaAnLT1 * 75 / 100);
                break;
            case AnLT2:
                thanhTien = soVe * (GiaAnLT2 * 75 / 100);
                break;
            case AnT1:
                thanhTien = soVe * (GiaAnT1 * 75 / 100);
                break;
            case AnT2:
                thanhTien = soVe * (GiaAnT2 * 75 / 100);
                break;
            case BnLT1:
                thanhTien = soVe * (GiaBnLT1 * 75 / 100);
                break;
            case BnLT2:
                thanhTien = soVe * (GiaBnLT2 * 75 / 100);
                break;
            case BnLT3:
                thanhTien = soVe * (GiaBnLT3 * 75 / 100);
                break;
            case BnT1:
                thanhTien = soVe * (GiaBnT1 * 75 / 100);
                break;
            case BnT2:
                thanhTien = soVe * (GiaBnT2 * 75 / 100);
                break;
            case BnT3:
                thanhTien = soVe * (GiaBnT3 * 75 / 100);
                break;
            case GP:
                thanhTien = soVe * (GiaGP * 75 / 100);
                break;
            case NC:
                thanhTien = soVe * (GiaNC * 75 / 100);
                break;
            case NCL:
                thanhTien = soVe * (GiaNCL * 75 / 100);
                break;
            case NM:
                thanhTien = soVe * (GiaNM * 75 / 100);
                break;
            case NML:
                thanhTien = soVe * (GiaNML * 75 / 100);
                break;
            case NML4V:
                thanhTien = soVe * (GiaNML4V * 75 / 100);
                break;
            default:
                break;
        }
        return thanhTien;
    }

}
