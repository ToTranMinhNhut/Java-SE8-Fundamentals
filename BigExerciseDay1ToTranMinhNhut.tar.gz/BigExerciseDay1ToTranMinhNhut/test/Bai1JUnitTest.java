/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import bigexerciseday1totranminhnhut.Bai1TinhCuocMobileInternet;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author hocvien
 */
public class Bai1JUnitTest {
    
    public Bai1JUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void ktTinhCuoc1() {
        double ex = 25000;
        double ac = Bai1TinhCuocMobileInternet.tinhCuoc("M25", 10000);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTinhCuoc2() {
        double ex = 70000;
        double ac = Bai1TinhCuocMobileInternet.tinhCuoc("MAX", 10000);
        assertEquals(ex, ac, 0);
    }
    
    //
    @Test
    public void ktTinhCuoc3() {
        double ex = 1500;
        double ac = Bai1TinhCuocMobileInternet.tinhCuoc("M0", 1000);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTinhCuoc4() {
        double ex = 0;
        double ac = Bai1TinhCuocMobileInternet.tinhCuoc("M0", 1000);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTinhCuoc5() {
        double ex = 70000;
        double ac = Bai1TinhCuocMobileInternet.tinhCuoc("MAX100", 1000);
        assertEquals(ex, ac, 0);
    }
    
    @Test
    public void ktTinhCuoc6() {
        double ex = 789877;
        double ac = Bai1TinhCuocMobileInternet.tinhCuoc("M120", 1000);
        assertEquals(ex, ac, 0);
    }
    
}
