/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai3totranminhnhut;

/**
 *
 * @author hocvien
 */
public class bai6Tinhketqua5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int x =10; 
        int y =4;
        boolean equivalence = x == y;
        System.out.println("x == y is " + equivalence);
        
        boolean nonEquivalence = x != y;
        System.out.println("x != y is " + nonEquivalence);
        
        boolean lessThan = x < y;
        System.out.println("x < y is " + lessThan);
        
        boolean greaterThan = x > y;
        System.out.println("x > y is " + greaterThan);
        
        boolean lessOrEqualTo = x <=y ;
        System.out.println("x <= y is " + lessOrEqualTo);
        
        boolean greaterOrEqualTo = x >= y;
        System.out.println("x >= y is " + greaterOrEqualTo);
        
        
    }
    
}
