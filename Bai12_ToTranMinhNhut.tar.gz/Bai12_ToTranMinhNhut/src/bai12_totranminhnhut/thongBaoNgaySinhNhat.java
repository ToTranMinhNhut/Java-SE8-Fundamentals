/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai12_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 *
 * @author hocvien
 */
public class thongBaoNgaySinhNhat {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException, ParseException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Nhap Ngay thang nam sinh: ");
        String ntnSinh = input.readLine();

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM");
        Date d = sdf.parse(ntnSinh);
        Calendar cal = Calendar.getInstance();
        cal.setTime(d);
        int ngaySinh = cal.get(Calendar.DAY_OF_YEAR);

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM");
        Calendar calendar = Calendar.getInstance();
        int ngayHienTai = calendar.get(Calendar.DAY_OF_YEAR) - 1;

        if (ngayHienTai == ngaySinh) {
            System.out.println("Chuc mung sinh nhat");
        } else if (ngayHienTai < ngaySinh) {
            System.out.println("Vui long cho doi. Chi con lai " + (ngaySinh - ngayHienTai) + " Ngay thoi");
        } else {
            System.out.println("Hen sinh nhat nam sau. Da qua " + (ngayHienTai - ngaySinh) + " Ngay Roi");
        }

    }

}
