/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai12_totranminhnhut;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author hocvien
 */
public class inNgayThangNam {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

        Calendar calender = Calendar.getInstance();
        
        SimpleDateFormat Thu = new SimpleDateFormat("E");
        System.out.println("Thu trong tuan: " + Thu.format(new Date()));
        System.out.println("Tuan trong nam: " + calender.get(Calendar.WEEK_OF_YEAR));
        
        Calendar calTemp;
        calTemp = (Calendar)calender.clone();
        
        calTemp.add(Calendar.DAY_OF_WEEK,7);
        
        System.out.println("Tuan sau: " + dateFormat.format(calTemp.getTime()));

    }

}
