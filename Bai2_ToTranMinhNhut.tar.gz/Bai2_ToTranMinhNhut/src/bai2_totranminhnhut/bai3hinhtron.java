/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai2_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


/**
 *
 * @author hocvien
 */
public class bai3hinhtron {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        final double PI = 3.14;

        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("nhap ban kinh");
        int bankinh = Integer.parseInt(input.readLine()) ;
        
        System.out.println("Chu vi: " + (2*bankinh*PI));
        System.out.println("Dien tich: " + (PI*bankinh*bankinh));
    }
    
}
