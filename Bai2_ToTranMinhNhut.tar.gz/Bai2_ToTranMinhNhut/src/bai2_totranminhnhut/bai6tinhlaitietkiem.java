/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai2_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai6tinhlaitietkiem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.println("lai suat 1 nam: ");
        double laisuat = Double.parseDouble(input.readLine());

        
        System.out.println("so tien gui: ");
        double tiengui = Double.parseDouble(input.readLine());
        
        System.out.println("so thang: ");
        int thang = Integer.parseInt(input.readLine());
        
        double tienlai = (tiengui*thang)*(laisuat/100/12);
        
        double tientong = tiengui + tienlai;
        
        System.out.println("tien lai: " + String.format("2.f", tienlai));
        System.out.println("tien tong: " + String.format("2.f", tientong));

        
    }
    
}
