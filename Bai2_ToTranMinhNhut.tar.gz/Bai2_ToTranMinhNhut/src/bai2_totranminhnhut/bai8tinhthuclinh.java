/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai2_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai8tinhthuclinh {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.println("so san pham: ");
        int sosanpham = Integer.parseInt(input.readLine());
        
        System.out.println("tien cong mot san pham: ");
        double tiencong = Double.parseDouble(input.readLine());
        
        System.out.println("tien thuong: ");
        double tienthuong = Double.parseDouble(input.readLine());
        
        System.out.println("so con: ");
        int socon = Integer.parseInt(input.readLine());

        double tienluong = sosanpham*tiencong;
        
        double phucap = socon*200000;
        
        double thuclinh = tienluong*tienthuong*phucap;
        
        System.out.println("Tien luong: " + String.format("%.2f", tienluong));
        System.out.println("Phu cap: " + String.format("%.2f", phucap));
        System.out.println("Thuc Linh: " + String.format("%.2f", thuclinh));


    }
    
}
