/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai2_totranminhnhut;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class bai7doitien {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.println("Ten ngoai te: ");
        String tentien = input.readLine();
        
        System.out.println("Ti gia: ");
        int tigia = Integer.parseInt(input.readLine());
        
        System.out.println("so ngoai te: ");
        int sotien = Integer.parseInt(input.readLine());
        
        int thanhtien = tigia*sotien ;
        
        System.out.println("ban dang doi tu: " + tentien + "sang VND" );
        System.out.println("Thanh tien: " + String.format("2.f",thanhtien));


    }
    
}
